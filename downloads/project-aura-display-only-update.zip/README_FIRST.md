# Project AURA — display-only update

This package is based on your attached `previous_code.txt` and `aura_phone_page.h`. The **heart-rate and SpO₂ calculations, their signal thresholds, sensor sampling/setup, alerts, commands and telemetry are unchanged**. No SpO₂ offset or simulated value has been added.

Changes are limited to:

- The watch and phone display temperature in **°C and °F**. The DS18B20 reading, telemetry `temp` and temperature alert threshold remain in Celsius. Sensor/skin temperature is not core body temperature.
- A ninth OLED screen and a phone section say **AQI · Coming soon**. No AQI sensor or measurement is included. Existing OLED screen IDs remain unchanged; tapping cycles through the new screen.
- OLED text is positioned in bounded rows; long text is shortened with `~` rather than wrapping into another row. On the temperature screen, `R`/`S` denotes the original raw/sim label and `M` the Celsius alert threshold when space permits.

## Important existing limitation

As requested, the original code is retained, including its SpO₂ calculation's **86–100% clamp**, which can conceal lower calculated values. A displayed 86% does not establish anyone's actual oxygen level. The MAX30102 readings are unvalidated, especially with the reported gap between sensor and wrist, and may be wrong; do not use them for medical decisions. Use a validated instrument instead.

## Upload

1. Extract the ZIP and open `project_aura_esp32c3/project_aura_esp32c3.ino` in Arduino IDE 2. Keep `aura_phone_page.h` in the same folder.
2. Select **ESP32C3 Dev Module** and set **USB CDC On Boot → Enabled**. Use your existing ESP32 board package and libraries: Adafruit SSD1306 and GFX, SparkFun MAX3010x, OneWire, and DallasTemperature.
3. Turn the battery switch **OFF** and unplug the charger before connecting the ESP32 USB data cable. Select the port, upload and reboot.
4. The watch cycles nine screens. On the phone, join **Project-AURA** (demo password `12345678`) and open **http://192.168.4.1/**. The updated header serves the updated phone page.

`project_aura_phone_web_app.html` is included as the readable source of the embedded phone page; editing it alone does not update the firmware header. The hotspot uses demo credentials and its HTTP controls are unauthenticated.

## Verification

The sketch compiled for ESP32-C3 with Espressif Arduino core 3.3.12. The display layout and phone page were tested with mocks/simulated input, not the physical device. A source comparison confirmed that, apart from OLED rendering and the nine-screen navigation change, the attached sketch is unchanged (line endings normalized).
