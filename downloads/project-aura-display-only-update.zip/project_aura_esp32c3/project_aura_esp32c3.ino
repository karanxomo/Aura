/*
 * ======================================================================================
 *  PROJECT AURA (Advanced UV & Risk-prediction Assistant) — Wearable Edge Firmware v3.0
 *  Target MCU: ESP32-C3 SuperMini (RISC-V @ 160 MHz, Wi-Fi + Native USB-C CDC)
 * ======================================================================================
 *
 *  ACTUAL WEARABLE HARDWARE BOM & PIN MAPPING (ESP32-C3 SuperMini):
 *  -------------------------------------------------------------------------------------
 *  1. 0.96" OLED (Yellow+Blue) : VCC -> 3V3 | GND -> GND | SDA -> GPIO 8 | SCL -> GPIO 9
 *                                (128x64 SSD1306 I2C: y=0..15 Yellow bar, y=16..63 Blue)
 *  2. MAX30102 Pulse Oximeter  : VIN -> 3V3 | GND -> GND | SDA -> GPIO 8 | SCL -> GPIO 9
 *                                (Black PCB module shares 400kHz I2C bus @ 0x57)
 *  3. ACEBOTT UV Sensor (QB104): VCC -> 3V3 | GND -> GND | SIG (S) -> GPIO 0 (ADC1_CH0)
 *                                (Provisional ADC-to-UVI mapping; verify output voltage and calibrate.)
 *  4. TP4056 BATTERY SENSE (user's 100k / 100k divider):
 *     TP4056 protected OUT+ -> slide switch ->[100k]--+--[100k]--> OUT- / GND
 *                                                      +--> GPIO 1 (ADC1)
 *     This reads cell voltage before the boost; TP4056 does not report percentage.
 *     The ratio is 2:1, and percentage is an APPROXIMATE voltage-based estimate.
 *     Disable sensing if the divider is removed. A floating input can look plausible.
 *     Have the actual wiring and midpoint voltage checked with a multimeter.
 *  5. DS18B20 Temp Probe       : VDD -> 3V3 | GND -> GND | DATA -> GPIO 3
 *                                (Connect your 10k resistor between GPIO 3 and 3V3!)
 *  6. TTP223R Touch (Red)      : VCC -> 3V3 | GND -> GND | I/O (SIG) -> GPIO 4
 *                                (Active-HIGH touch: Tap = Next/ACK, Double-Tap = Skin
 *                                 Sensitivity Mode, Long-Hold = Log Sunscreen SPF!)
 *  7. Coin Vibration Motor     : GPIO 5 -> transistor DRIVER; motor + -> rated supply;
 *                                motor - -> transistor; flyback diode across motor REQUIRED.
 *  8. Mini Buzzer              : GPIO 10 -> suitable driver/module; do not exceed GPIO rating.
 *  GPIO 8 and 9 are now the shared I2C bus: the firmware does NOT drive an
 *  onboard LED or poll BOOT. Both are strapping pins; validate reset/boot and
 *  check onboard LED, BOOT and 3.3V pull-ups on the specific SuperMini board.
 *
 *  POWER CHAIN SAFETY NOTE:
 *  3.7V LiPo (523450) -> TP4056 Type-C (B+/B-) -> TP4056 OUT+ -> 3-Pin Slide Switch ->
 *  Mini DC-DC Boost VIN+ -> Boost VOUT+ -> ESP32-C3 5V pin.
 *  Some A/B-selectable boost boards default to 12V; A=0,B=0 commonly selects 5V.
 *  VERIFY YOUR BOARD and measure 5.0V at the output before connecting the ESP32.
 *  Turn Slide Switch OFF before plugging USB-C into ESP32-C3 for flashing/Web Serial.
 *  Turn the load OFF while charging via TP4056; see hardware guide for LiPo protection,
 *  charge current, backfeed, and voltage validation. Never connect a motor directly to GPIO.
 *
 *  PROTOTYPE ONLY: Outputs and score are experimental, not clinical or UV protection
 *  advice. Invalid MAX30102 contact, DS18B20 or battery sense is flagged as unavailable.
 *  The analog UV input cannot detect a disconnected sensor. Calibrate against a reference.
 *
 *  ARDUINO IDE 2.x SETTINGS (CRITICAL FOR ESP32-C3 SUPERMINI):
 *  - Board            : "ESP32C3 Dev Module"
 *  - USB CDC On Boot  : "Enabled"   <-- Required for USB Web Serial Bridge!
 *
 *  REQUIRED ARDUINO LIBRARIES (Sketch -> Include Library -> Manage Libraries):
 *  1. Adafruit SSD1306                        (by Adafruit)
 *  2. Adafruit GFX Library                    (by Adafruit)
 *  3. SparkFun MAX3010x Pulse and Proximity   (by SparkFun Electronics -> MAX30105.h)
 *  4. OneWire                                 (by Paul Stoffregen)
 *  5. DallasTemperature                       (by Miles Burton)
 * ======================================================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MAX30105.h>
#include <heartRate.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Preferences.h> // Bundled with the ESP32 Arduino core; stores confirmed battery wiring setting.
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include "aura_phone_page.h"

// ---------------- ESP32-C3 SUPERMINI PIN DEFINITIONS ----------------
#define PIN_UV_ADC      0   // ADC1_CH0: ACEBOTT UV Sensor analog output (0-1100 mV)
#define PIN_BAT_ADC     1   // ADC1_CH1: switched protected output via 100k / 100k divider
#define PIN_DS18B20     3   // OneWire DATA (+ 10k pull-up resistor to 3V3)
#define PIN_TOUCH       4   // TTP223R Red Capacitive Touch SIG (Active-HIGH default)
#define PIN_VIB_MOTOR   5   // Coin Vibration Motor haptic output
#define PIN_I2C_SDA     8   // Shared I2C SDA: strapping pin; verify boot and onboard LED
#define PIN_I2C_SCL     9   // Shared I2C SCL: strapping pin; BOOT pressed at reset enters download mode
#define PIN_BUZZER     10   // Mini Buzzer output (Active DC or Passive PWM Tone)

// Default ON for the user's confirmed, installed 100k / 100k divider.
// A previous saved dashboard setting still overrides this default: if it was OFF,
// enable the battery estimate once in the phone settings after checking the wiring.
// Set to 0 or disable in the dashboard BEFORE removing the divider. A plausible ADC
// value cannot prove that a battery/divider is actually connected or safely wired.
#define AURA_TP4056_DIVIDER_WIRED_DEFAULT 1

// ---------------- WI-FI SOFTAP SETTINGS ----------------
const char* AP_SSID = "Project-AURA";
const char* AP_PASS = "12345678";   // Connect laptop/phone -> http://192.168.4.1

// ---------------- 0.96" YELLOW+BLUE SSD1306 OLED ----------------
// Top 16 rows (y = 0..15) = YELLOW zone | Bottom 48 rows (y = 16..63) = BLUE zone
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT   64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
bool oledOk = false;
uint8_t oledAddr = 0x3C;

// ---------------- SENSORS & SERVER OBJECTS ----------------
MAX30105 particleSensor;
bool maxOk = false;

OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
bool dsSensorFound = false;

WebServer server(80);

// ---------------- LIVE TELEMETRY & EDGE STATE ----------------
int   hrBpm        = 78;     // Live Heart Rate (BPM)
int   spo2Pct      = 98;     // Live Blood Oxygen (%)
float tempC        = 36.8f;  // Calibrated Body/Skin Temperature (C)
float rawTempC     = 28.0f;  // Raw DS18B20 reading (C)
float uvIndexFloat = 1.8f;   // Precise UV Index (0.0 - 12.0)
int   uvIndex      = 2;      // Rounded UV Index (0 - 12)
int   uvMilliVolts = 180;    // ACEBOTT UV raw calibrated mV

// Battery Percentage State (3.7V 523450 LiPo)
int   batPct       = 0;
float batVolts     = 0.0f;
bool  batterySenseEnabled = AURA_TP4056_DIVIDER_WIRED_DEFAULT != 0; // Confirmed wired only
bool  batterySenseSaveOk = true;    // Last attempt to save wiring configuration succeeded
bool  batHwDetected = false;       // Enabled + plausible ADC; cannot detect every disconnected wire
bool  batValid = false;            // False until enabled+valid or demo override is active
int   simBat = 85;                 // Synthetic; used ONLY while simOverride=true
const float BAT_DIVIDER_RATIO = 2.0f; // Equal 100k / 100k -> Vbat = Vadc * 2.0
// Real ADC diagnostic; -1 means no completed hardware batch (disabled/test/waiting).
int batAdcMv = -1;
const uint8_t BAT_SAMPLE_COUNT = 20;
const unsigned long BAT_SAMPLE_SPACING_MS = 10;
const unsigned long BAT_BATCH_PAUSE_MS = 2000;
const unsigned long BAT_STALE_MS = 8000;
uint32_t batSampleSumMv = 0;
uint8_t batSamplesTaken = 0;
unsigned long batLastSampleMs = 0, batLastBatchMs = 0;
bool batBatchActive = false, batHasBatch = false;

// MAX30102 Non-Blocking PPG & R-Ratio SpO2 State
bool     fingerDetected = false;
bool     hrValid = false, spo2Valid = false, tempValid = false;
unsigned long lastHrGoodMs = 0, lastSpo2GoodMs = 0, lastPpgSampleMs = 0;
uint8_t  validBeatCount = 0;
uint32_t latestIr       = 0;
uint32_t latestRed      = 0;
unsigned long lastBeatMs = 0;
uint8_t  beatHist[6]    = {0, 0, 0, 0, 0, 0};
uint8_t  beatIdx        = 0;
float    bpmEma         = 78.0f;
float    spo2Ema        = 98.0f;

// Rolling 100-sample AC/DC accumulator for non-blocking SpO2 (~1 sec @ 100 sps)
uint16_t ppgWinCount = 0;
double   irSum = 0, redSum = 0;
uint32_t irMin = 0xFFFFFFFF, irMax = 0;
uint32_t redMin = 0xFFFFFFFF, redMax = 0;

// Optional Demo Vital Override (lets Web App test Hypoxia/Tachycardia on real Watch!)
bool  simOverride = false;
int   simHr       = 78;
int   simSpo2     = 98;
float simTemp     = 36.8f;
int   simUv       = 2;       // Test mode replaces UV as well as all other sensor values.

// Calibration & Personalization Settings (Two-Way Synced with Web App)
bool  sensitiveSkin = false; // Separate from self-reported skin type.
uint8_t skinType = 0;         // 0 = not sure; 1..6 = illustrative Fitzpatrick types.
bool skinSaveOk = true;       // False if the latest NVS write failed.
bool skinSaved = false;       // True only when BOTH settings are reported saved.
bool clockValid = false;      // Clock must be synced after each complete reset/power loss.
int clockTzMinutes = 0;       // Phone-provided UTC offset; refresh for travel or DST.
bool  useBodyOffset = false; // DEMO ONLY. A fixed offset is NOT core temperature.
float tempOffset    = 0.0f;
float uvGain        = 1.0f;  // 1.0x sunlight, or >1.0x indoor demo boost
int   sunElapsedMin = 0;     // Real elapsed minutes since last logged application
bool  spfLogged = false;     // Do not assume sunscreen was applied at startup.
float exposureMinutes = 0.0f; // Approx. time with UV index >= 1 (not a clinical dose)
float uvIndexMinutes = 0.0f;  // Integral of estimated UV index over minutes
bool  standaloneSim = false; // Mirrors the dashboard snapshot pause; no BLE is implemented.

// Safety Thresholds (Editable from Mobile/Web App, Evaluated Locally on Edge!)
int   thHrLow  = 50;
int   thHrHigh = 120;
int   thSpo2   = 92;
float thTemp   = 38.0f;

// Composite Safety Scoring & Edge Alert Engine
int   auraScore     = 94;    // 0 - 100 Composite Safety Score
const char* auraBand = "NO DATA";
bool  scoreValid = false;
bool  heatStrainPred = false; // Synergistic Heat + UV Risk Prediction flag
bool  alertActive    = false;
bool  alertUrgent    = false;
bool  alertLatched   = false;
uint8_t activeAlertCount = 0;
String topAlertTitle = "ALL SAFE";
String topAlertDetail = "Vitals & UV nominal";
uint16_t prevRuleMask = 0;

// OLED Watch Navigation (9 Screens: 0..8; prior screen IDs are unchanged)
// 0: Home + AURA Score | 1: Heart (MAX30102) | 2: SpO2 (MAX30102) | 3: Temp (DS18B20)
// 4: UV + Sunscreen    | 5: Battery & Power  | 6: Edge Alerts | 7: Clock | 8: AQI
int  watchScreen = 0;
const int NUM_SCREENS = 9;

// Event Sequence Counters for Instant Two-Way Web Sync
unsigned long scrSeq  = 0;
unsigned long ackSeq  = 0;
unsigned long sunSeq  = 0;
unsigned long sensSeq = 0;
String lastTouchGesture = "none";

// TTP223R Capacitive Touch + BOOT Button Gesture State Machine
bool invTouch         = false; // False = Active-HIGH (TTP223 default A=0,B=0)
bool touchNow         = false;
bool touchRawPrev     = false;
bool touchStable      = false;
unsigned long touchDebounceMs = 0;
unsigned long touchDownMs     = 0;
bool touchLongHandled = false;
uint8_t tapPendingCount = 0;
unsigned long lastTapReleaseMs = 0;

// Non-Blocking Coin Vibration Motor (GPIO 5) & Mini Buzzer (GPIO 10) Sequencers
bool vibEnabled  = true;
bool buzEnabled  = true;
int  buzMode     = 1;     // 0 = Active DC buzzer, 1 = Passive PWM tone() mini buzzer
bool invBuz      = false; // True if active-LOW transistor driver

bool vibCurrentlyOn = false;
unsigned long vibOffAtMs = 0;
uint8_t vibPulsesLeft = 0;
unsigned long vibNextPulseMs = 0;

bool buzCurrentlyOn = false;
unsigned long buzOffAtMs = 0;
unsigned long lastAlarmCycleMs = 0;

// Loop Timing
unsigned long lastSensorMs = 0;
unsigned long lastTempMs   = 0;
unsigned long lastOledMs   = 0;
unsigned long lastSerialMs = 0;
unsigned long lastMinuteMs = 0;
unsigned long lastExposureMs = 0;

// ======================================================================================
//  ACTUATOR DRIVERS: COIN VIBRATION MOTOR (GPIO 5) & MINI BUZZER (GPIO 10)
// ======================================================================================
void setVibMotorRaw(bool on) {
  vibCurrentlyOn = on;
  digitalWrite(PIN_VIB_MOTOR, on ? HIGH : LOW);
}

void triggerHapticPulses(uint8_t count, uint16_t onMs) {
  if (!vibEnabled || count == 0) return;
  setVibMotorRaw(true);
  vibOffAtMs = millis() + onMs;
  vibPulsesLeft = count - 1;
}

void setBuzzerRaw(bool on, uint16_t freqHz = 2400) {
  buzCurrentlyOn = on;
  if (buzMode == 1) {
    if (on) tone(PIN_BUZZER, freqHz);
    else noTone(PIN_BUZZER);
  } else {
    bool level = invBuz ? !on : on;
    digitalWrite(PIN_BUZZER, level ? HIGH : LOW);
  }
}

void triggerAudioPip(uint16_t durationMs, uint16_t freqHz = 2200) {
  if (!buzEnabled) return;
  setBuzzerRaw(true, freqHz);
  buzOffAtMs = millis() + durationMs;
}

void serviceActuators() {
  unsigned long now = millis();

  // Finish single/multi haptic pulse
  if (vibCurrentlyOn && vibOffAtMs > 0 && now >= vibOffAtMs) {
    setVibMotorRaw(false);
    vibOffAtMs = 0;
    if (vibPulsesLeft > 0) {
      vibNextPulseMs = now + 70;
    }
  }
  if (!vibCurrentlyOn && vibPulsesLeft > 0 && now >= vibNextPulseMs) {
    vibPulsesLeft--;
    setVibMotorRaw(true);
    vibOffAtMs = now + 55;
  }

  // Finish one-shot buzzer pip
  if (buzCurrentlyOn && buzOffAtMs > 0 && now >= buzOffAtMs) {
    setBuzzerRaw(false);
    buzOffAtMs = 0;
  }

  // Periodic repeating alarm pattern while an unacknowledged Edge Alert is active
  if (alertLatched && alertActive) {
    unsigned long period = alertUrgent ? 1400 : 2800;
    if (now - lastAlarmCycleMs >= period) {
      lastAlarmCycleMs = now;
      if (vibEnabled) triggerHapticPulses(alertUrgent ? 2 : 1, alertUrgent ? 140 : 90);
      if (buzEnabled) triggerAudioPip(alertUrgent ? 180 : 100, alertUrgent ? 2700 : 1850);
    }
    // GPIO 8 is SDA; do not drive the onboard LED while the I2C bus is in use.
  }
}

// ======================================================================================
//  TP4056 / SINGLE-CELL BATTERY SENSE CONFIGURATION AND ESTIMATE
// ======================================================================================
// A floating ADC can give a plausible reading, so do not auto-detect a divider.
// Explicit confirmation is stored in ESP32 NVS; disable it BEFORE removing the divider.
void restoreBatterySenseSetting() {
  Preferences prefs;
  if (prefs.begin("aura-power", true)) {
    batterySenseEnabled = prefs.getBool("tp_sense", AURA_TP4056_DIVIDER_WIRED_DEFAULT != 0);
    prefs.end();
  }
}

bool saveBatterySenseSetting(bool enabled) {
  Preferences prefs;
  if (!prefs.begin("aura-power", false)) return false;
  size_t written = prefs.putBool("tp_sense", enabled);
  prefs.end();
  return written == 1;
}

// User profile persistence is separate from battery wiring confirmation.
void restoreSkinProfile() {
  Preferences prefs;
  if (prefs.begin("aura-profile", true)) {
    skinSaved = prefs.isKey("skin") && prefs.isKey("sens");
    skinType = constrain((int)prefs.getUChar("skin", 0), 0, 6);
    sensitiveSkin = prefs.getBool("sens", false);
    prefs.end();
  }
}

bool saveSkinProfile() {
  Preferences prefs;
  if (!prefs.begin("aura-profile", false)) { skinSaved = false; return false; }
  size_t a = prefs.putUChar("skin", skinType);
  size_t b = prefs.putBool("sens", sensitiveSkin);
  prefs.end();
  skinSaved = (a == 1 && b == 1);
  return skinSaved;
}

void setSkinProfile(uint8_t nextType, bool nextSensitivity) {
  nextType = constrain((int)nextType, 0, 6);
  if (nextType != skinType || nextSensitivity != sensitiveSkin || !skinSaved || !skinSaveOk) {
    skinType = nextType;
    sensitiveSkin = nextSensitivity;
    skinSaveOk = saveSkinProfile();
  }
}

// Phone sends Unix epoch seconds and UTC offset; no external RTC is needed.
bool parseWholeNumber(const String& text, long long &out) {
  if (!text.length()) return false;
  char *end = nullptr;
  const char *start = text.c_str();
  long long n = strtoll(start, &end, 10);
  if (end == start || *end != '\0') return false;
  out = n;
  return true;
}
void setPhoneEpoch(const String& value) {
  long long seconds;
  if (!parseWholeNumber(value, seconds) || seconds < 1700000000LL || seconds > 4102444800LL) return;
  struct timeval tv = {};
  tv.tv_sec = (time_t)seconds;
  if (settimeofday(&tv, nullptr) == 0) clockValid = true;
}
void setPhoneOffset(const String& value) {
  long long offset;
  if (parseWholeNumber(value, offset) && offset >= -720 && offset <= 840) clockTzMinutes = (int)offset;
}
String formattedWatchClock() {
  if (!clockValid) return "--:--";
  time_t shifted = time(nullptr) + (time_t)clockTzMinutes * 60;
  struct tm local = {};
  if (!gmtime_r(&shifted, &local)) return "--:--";
  char text[6];
  snprintf(text, sizeof(text), "%02d:%02d", local.tm_hour, local.tm_min);
  return String(text);
}

// Same illustrative voltage-to-percentage curve as the user's battery test sketch.
// Voltage alone is not a reliable fuel gauge or charge-state indicator.
// ======================================================================================
int lipoVoltsToPercent(float v) {
  const float voltages[] = {3.30f, 3.50f, 3.60f, 3.70f, 3.75f, 3.80f,
                            3.85f, 3.90f, 3.95f, 4.00f, 4.10f, 4.20f};
  const int percentages[] = {0, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
  if (v <= voltages[0]) return 0;
  if (v >= voltages[11]) return 100;
  for (int i = 0; i < 11; ++i) {
    if (v >= voltages[i] && v <= voltages[i + 1]) {
      float ratio = (v - voltages[i]) / (voltages[i + 1] - voltages[i]);
      return percentages[i] + ratio * (percentages[i + 1] - percentages[i]);
    }
  }
  return 0;
}

float percentToLipoVolts(int pct) {
  return 3.30f + (constrain(pct, 0, 100) / 100.0f) * 0.90f;
}

// ======================================================================================
//  ACEBOTT UV SENSOR (QB104) MILLIVOLT -> UV INDEX CONVERTER
// ======================================================================================
float mvToUvIndex(int mv) {
  // Provisional DEMO mapping based on the listing's 0–1100 mV claim.
  // The manufacturer also gives conflicting 0–5V guidance; verify output voltage and
  // calibrate vs a reference. Spectral response is not a certified UV-index instrument.
  return constrain(mv / 100.0f, 0.0f, 12.0f);
}

// ======================================================================================
//  NON-BLOCKING MAX30102 HEART RATE & SpO2 ENGINE
// ======================================================================================
void pollMax30102() {
  if (!maxOk) return;
  particleSensor.check();

  uint8_t drained = 0;
  while (particleSensor.available() && drained < 10) {
    drained++;
    uint32_t red = particleSensor.getFIFORed();
    uint32_t ir  = particleSensor.getFIFOIR();
    particleSensor.nextSample();

    latestIr  = ir;
    latestRed = red;
    lastPpgSampleMs = millis();

    if (ir < 45000) {
      // Never present stale or initial demo vitals as real readings.
      fingerDetected = false;
      hrValid = spo2Valid = false;
      lastBeatMs = lastHrGoodMs = lastSpo2GoodMs = 0;
      validBeatCount = beatIdx = 0;
      ppgWinCount = 0;
      irSum = 0; redSum = 0;
      irMin = 0xFFFFFFFF; irMax = 0;
      redMin = 0xFFFFFFFF; redMax = 0;
      continue;
    }

    fingerDetected = true;

    // 1. Beat detection for live BPM
    if (checkForBeat(ir)) {
      unsigned long now = millis();
      unsigned long delta = lastBeatMs ? now - lastBeatMs : 0;
      lastBeatMs = now;
      if (delta >= 300 && delta <= 1500) { // 40–200 BPM
        float instantBpm = 60000.0f / (float)delta;
        beatHist[beatIdx] = (uint8_t)constrain((int)roundf(instantBpm), 42, 195);
        beatIdx = (beatIdx + 1) % 6;
        if (validBeatCount < 6) validBeatCount++;
        int sum = 0;
        for (int i = 0; i < validBeatCount; i++) sum += beatHist[i];
        float avgBpm = sum / (float)validBeatCount;
        bpmEma = (validBeatCount == 1) ? avgBpm : 0.70f * bpmEma + 0.30f * avgBpm;
        lastHrGoodMs = now;
        hrValid = validBeatCount >= 2; // Need multiple beats, not a fabricated baseline.
        if (!simOverride) hrBpm = constrain((int)roundf(bpmEma), 40, 195);
      }
    }

    // 2. Rolling 100-sample AC/DC Ratio-of-Ratios for SpO2
    irSum += ir;
    redSum += red;
    if (ir < irMin) irMin = ir;
    if (ir > irMax) irMax = ir;
    if (red < redMin) redMin = red;
    if (red > redMax) redMax = red;
    ppgWinCount++;

    if (ppgWinCount >= 100) {
      double irDc  = irSum / 100.0;
      double redDc = redSum / 100.0;
      double irAc  = (double)(irMax - irMin);
      double redAc = (double)(redMax - redMin);

      if (irDc > 1000.0 && redDc > 1000.0 && irAc > 60.0 && irAc < 15000.0) {
        double rRatio = (redAc / redDc) / (irAc / irDc);
        double calcSpo2 = 104.0 - 17.0 * rRatio;
        calcSpo2 = constrain(calcSpo2, 86.0, 100.0);
        spo2Ema = spo2Valid ? (0.80f * spo2Ema + 0.20f * (float)calcSpo2) : (float)calcSpo2;
        spo2Valid = true;
        lastSpo2GoodMs = millis();
        if (!simOverride) {
          spo2Pct = constrain((int)roundf(spo2Ema), 85, 100);
        }
      }
      ppgWinCount = 0;
      irSum = 0; redSum = 0;
      irMin = 0xFFFFFFFF; irMax = 0;
      redMin = 0xFFFFFFFF; redMax = 0;
    }
  }
  if (fingerDetected && millis() - lastPpgSampleMs > 1500) fingerDetected = false;
  if (hrValid && millis() - lastHrGoodMs > 5000) hrValid = false;
  if (spo2Valid && millis() - lastSpo2GoodMs > 5000) spo2Valid = false;
}

// ======================================================================================
//  NON-BLOCKING BATTERY ADC: 20 samples, at least 10 ms apart, like the user's test.
// ======================================================================================
// Spreading samples over loop() avoids the test sketch's 200 ms blocking delay, so
// the integrated MAX30102, Wi-Fi, touch and OLED remain serviced. ADC is still noisy;
// interleaved UV reads and a high-impedance 100k/100k divider can change results.
void resetBatterySampler() {
  batSampleSumMv = 0;
  batSamplesTaken = 0;
  batLastSampleMs = batLastBatchMs = 0;
  batBatchActive = batHasBatch = false;
  batAdcMv = -1;
  batHwDetected = batValid = false;
}

void pollBattery() {
  const unsigned long now = millis();
  if (simOverride) {
    batHwDetected = false;
    batValid = true;
    batPct = simBat;
    batVolts = percentToLipoVolts(simBat); // Synthetic and labelled TEST.
    return;
  }
  if (!batterySenseEnabled) {
    batHwDetected = batValid = false;
    return;
  }
  // Do not keep an old estimate if a sampling batch cannot complete.
  if (batHasBatch && now - batLastBatchMs > BAT_STALE_MS) {
    batHwDetected = batValid = false;
    batAdcMv = -1;
  }
  if (!batBatchActive) {
    if (batHasBatch && now - batLastBatchMs < BAT_BATCH_PAUSE_MS) return;
    batBatchActive = true;
    batSampleSumMv = 0;
    batSamplesTaken = 0;
    batLastSampleMs = now - BAT_SAMPLE_SPACING_MS; // first sample is due now
  }
  if (now - batLastSampleMs < BAT_SAMPLE_SPACING_MS) return;
  batLastSampleMs = now;
  // Discard a conversion to reduce possible channel-switch carryover from GPIO 0.
  // This cannot correct every error caused by the divider's higher impedance.
  (void)analogReadMilliVolts(PIN_BAT_ADC);
  batSampleSumMv += analogReadMilliVolts(PIN_BAT_ADC);
  if (++batSamplesTaken < BAT_SAMPLE_COUNT) return;

  const float adcBatMv = batSampleSumMv / (float)BAT_SAMPLE_COUNT;
  batAdcMv = (int)roundf(adcBatMv); // diagnostic retained even if out of range
  batLastBatchMs = millis();
  batHasBatch = true;
  batBatchActive = false;
  // This range filter is NOT proof of wiring, safe power or battery health.
  batHwDetected = batValid = (adcBatMv >= 1200.0f && adcBatMv <= 2300.0f);
  if (batValid) {
    batVolts = (adcBatMv / 1000.0f) * BAT_DIVIDER_RATIO;
    batPct = constrain(lipoVoltsToPercent(batVolts), 0, 100);
  }
}

// ======================================================================================
//  POLL ANALOG UV (GPIO 0), BATTERY % (GPIO 1) & DS18B20 TEMP (GPIO 3)
// ======================================================================================
void pollAnalogAndTemp() {
  unsigned long now = millis();

  // Every 80ms: Sample the ACEBOTT UV sensor; battery sampling is separate below.
  if (now - lastSensorMs >= 80) {
    lastSensorMs = now;

    // 1. ACEBOTT UV Sensor on GPIO 0 (8x oversampled factory-calibrated millivolts)
    long mvAcc = 0;
    for (int i = 0; i < 8; i++) mvAcc += analogReadMilliVolts(PIN_UV_ADC);
    int rawUvMv = (int)(mvAcc / 8);
    uvMilliVolts = rawUvMv;

    float scaledMv = rawUvMv * uvGain;
    static float uvFloatEma = -1.0f;
    float targetUv = mvToUvIndex((int)scaledMv);
    if (uvFloatEma < 0) uvFloatEma = targetUv;
    uvFloatEma = 0.78f * uvFloatEma + 0.22f * targetUv;

    if (simOverride) {
      uvIndexFloat = (float)simUv;
      uvIndex = constrain(simUv, 0, 12);
    } else {
      uvIndexFloat = roundf(constrain(uvFloatEma, 0.0f, 12.0f) * 10.0f) / 10.0f;
      uvIndex = constrain((int)roundf(uvIndexFloat), 0, 12);
    }

    // Apply Web Demo Override if enabled for HR/SpO2/Temp
    if (simOverride) {
      hrBpm   = simHr;
      spo2Pct = simSpo2;
      tempC   = simTemp;
    }
  }

  // Take one scheduled battery sample without blocking the rest of the loop.
  pollBattery();

  // Every 800ms: Non-blocking DS18B20 Temperature Probe on GPIO 3
  if (now - lastTempMs >= 800) {
    lastTempMs = now;
    if (dsSensorFound) {
      float t = ds18b20.getTempCByIndex(0);
      if (t > -30.0f && t < 85.0f) {
        rawTempC = t;
        tempValid = true;
        if (!simOverride) {
          tempC = useBodyOffset ? (rawTempC + tempOffset) : rawTempC;
          tempC = roundf(constrain(tempC, -20.0f, 85.0f) * 10.0f) / 10.0f;
        }
      } else {
        tempValid = false;
      }
      ds18b20.requestTemperatures();
    } else {
      tempValid = false;
    }
  }

  // SPF timer is elapsed clock time, not just time spent under a UV lamp.
  if (now - lastMinuteMs >= 60000) {
    lastMinuteMs += 60000;
    if (spfLogged && sunElapsedMin < 240) sunElapsedMin++;
  }
  // Approximate exposure only: zero voltage cannot prove that the UV sensor is connected.
  if (now - lastExposureMs >= 1000) {
    float dtMinutes = (now - lastExposureMs) / 60000.0f;
    lastExposureMs = now;
    if (!simOverride && uvIndexFloat >= 1.0f) { // Do not contaminate real counters with demo UV.
      exposureMinutes += dtMinutes;
      uvIndexMinutes += uvIndexFloat * dtMinutes;
    }
  }
}

bool hasHr() { return simOverride || (maxOk && fingerDetected && hrValid); }
bool hasSpo2() { return simOverride || (maxOk && fingerDetected && spo2Valid); }
bool hasTemp() { return simOverride || (dsSensorFound && tempValid); }

// ======================================================================================
//  PROJECT AURA COMPOSITE SAFETY SCORING & STANDALONE EDGE SAFETY ENGINE
// ======================================================================================
int sunLimitMinutes() {
  return sensitiveSkin ? 60 : 120;
}

void evaluateEdgeSafety() {
  int warnUv = sensitiveSkin ? 2 : 3;
  int urgUv  = (sensitiveSkin || skinType <= 2) ? 5 : 6;
  int sLim   = sunLimitMinutes();

  // --- 1. Compute Composite Safety Score (0 - 100) ---
  float penalty = 0.0f;

  // (a) UV demo heuristic: self-reported type and separate sensitivity both matter.
  // Not a validated personal risk model or a safe-exposure limit. Type 0 is cautious.
  const float factors[] = {1.25f, 1.25f, 1.20f, 1.15f, 1.10f, 1.05f, 1.00f};
  float effUv = (uvIndexFloat * factors[skinType]) * (sensitiveSkin ? 1.35f : 1.0f);
  if (effUv > 2.0f) {
    penalty += min(38.0f, (effUv - 2.0f) * 4.0f);
  }
  if ((!spfLogged || sunElapsedMin >= sLim) && uvIndex >= 3) {
    penalty += 8.0f;
  }

  // (b) Cardiovascular Strain Penalty (BPM)
  if (hasHr() && hrBpm > thHrHigh) {
    penalty += 18.0f + min(14.0f, (hrBpm - thHrHigh) * 0.45f);
  } else if (hasHr() && hrBpm < thHrLow) {
    penalty += 18.0f + min(14.0f, (thHrLow - hrBpm) * 0.65f);
  } else if (hasHr() && hrBpm > (thHrHigh - 14)) {
    penalty += (hrBpm - (thHrHigh - 14)) * 0.4f;
  }

  // (c) Blood Oxygen Penalty (SpO2)
  if (hasSpo2() && spo2Pct < thSpo2) {
    penalty += 22.0f + min(16.0f, (thSpo2 - spo2Pct) * 3.0f);
  } else if (hasSpo2() && spo2Pct < 96) {
    penalty += (96 - spo2Pct) * 2.0f;
  }

  // (d) Thermal Load Penalty (DS18B20)
  if (hasTemp() && tempC > thTemp) {
    penalty += 18.0f + min(14.0f, (tempC - thTemp) * 10.0f);
  } else if (hasTemp() && tempC > 37.3f) {
    penalty += (tempC - 37.3f) * 9.0f;
  }

  // (e) AURA Synergistic Heat-UV Risk Prediction Cross-Term
  heatStrainPred = (uvIndex >= ((sensitiveSkin || skinType <= 2) ? 4 : 6)) &&
                   ((hasTemp() && tempC >= 37.4f) || (hasHr() && hrBpm >= (thHrHigh - 12)));
  if (heatStrainPred) {
    penalty += 12.0f;
  }

  scoreValid = hasHr() && hasSpo2() && hasTemp();
  auraScore = scoreValid ? constrain((int)roundf(100.0f - penalty), 0, 100) : -1;
  auraBand  = !scoreValid ? "NO DATA" : (auraScore >= 80) ? "OPTIMAL" : (auraScore >= 55) ? "CAUTION" : "HIGH RISK";

  // --- 2. Standalone Edge Alert Rule Evaluation ---
  uint16_t mask = 0;
  activeAlertCount = 0;
  alertUrgent = false;
  topAlertTitle = "ALL SAFE";
  topAlertDetail = scoreValid ? ("Score " + String(auraScore) + "/100") : "Check vital sensors";

  auto addAlert = [&](uint8_t bit, bool urgent, const char* title, String detail) {
    mask |= (1 << bit);
    if (activeAlertCount == 0 || (urgent && !alertUrgent)) {
      topAlertTitle = title;
      topAlertDetail = detail;
    }
    if (urgent) alertUrgent = true;
    activeAlertCount++;
  };

  if (uvIndex >= urgUv) {
    addAlert(0, true, uvIndex >= 11 ? "EXTREME UV!" : "HIGH UV RISK",
             "UV " + String(uvIndex) + (sensitiveSkin ? " (Sens)" : "") + " Seek shade");
  }
  if (hasSpo2() && spo2Pct < thSpo2) {
    addAlert(1, true, "LOW SpO2!", "SpO2 " + String(spo2Pct) + "% < " + String(thSpo2) + "%");
  }
  if (hasHr() && hrBpm > thHrHigh) {
    addAlert(2, true, "HIGH PULSE!", String(hrBpm) + " BPM > " + String(thHrHigh));
  } else if (hasHr() && hrBpm < thHrLow) {
    addAlert(3, true, "LOW PULSE!", String(hrBpm) + " BPM < " + String(thHrLow));
  }
  if (hasTemp() && tempC > thTemp) {
    addAlert(4, true, "HIGH TEMP!", String(tempC, 1) + "C > " + String(thTemp, 1) + "C");
  }
  if (heatStrainPred && activeAlertCount == 0) {
    addAlert(5, false, "HEAT-UV STRAIN", "Compound UV+Thermal risk");
  } else if (uvIndex >= warnUv && uvIndex < urgUv) {
    addAlert(5, false, "UV ADVISORY", "UV " + String(uvIndex) + ": Wear SPF 30+");
  }
  if (!spfLogged && uvIndex >= 3) {
    addAlert(6, false, "LOG SPF", "SPF not logged yet");
  } else if (spfLogged && sunElapsedMin >= sLim) {
    addAlert(6, false, "REAPPLY SPF", String(sunElapsedMin) + "m elapsed");
  }
  if (batValid && batPct <= 15) {
    addAlert(7, false, "LOW BATTERY", "LiPo at " + String(batPct) + "% (" + String(batVolts, 2) + "V)");
  }
  if (!scoreValid && !simOverride && millis() > 10000UL) {
    addAlert(8, false, "SENSOR SIGNAL", hasTemp() ? "Check MAX contact" : "Check DS18B20");
  }

  alertActive = (activeAlertCount > 0);

  // Trigger Edge Takeover when any NEW alert bit turns ON
  uint16_t newlyFired = mask & (~prevRuleMask);
  if (newlyFired != 0) {
    alertLatched = true;
    watchScreen = 6; // Jump OLED straight to Edge Alert screen
    lastAlarmCycleMs = 0; // Fire immediate haptic + buzzer alert
  }
  if (!alertActive) {
    alertLatched = false;
  }
  prevRuleMask = mask;
}

// ======================================================================================
//  TTP223R CAPACITIVE TOUCH (GPIO 4) GESTURE ENGINE
//  - Single Tap  : Dismiss Active Alert OR Cycle OLED Watch Screen (0..8)
//  - Double Tap  : Toggle Personalized Skin Sensitivity Mode (Normal <-> Sensitive)
//  - Long Hold   : Log Sunscreen Reapplication (resets SPF timer)
// ======================================================================================
void pollTouchGestures() {
  unsigned long now = millis();

  bool rawActive = invTouch ? (digitalRead(PIN_TOUCH) == LOW) : (digitalRead(PIN_TOUCH) == HIGH);
  touchNow = rawActive;

  if (rawActive != touchRawPrev) {
    touchDebounceMs = now;
    touchRawPrev = rawActive;
  }

  if ((now - touchDebounceMs) > 28) {
    // Rising edge: Finger touched TTP223R pad
    if (rawActive && !touchStable) {
      touchStable = true;
      touchDownMs = now;
      touchLongHandled = false;
      triggerHapticPulses(1, 35); // Crisp tactile touch response!
    }

    // Held >= 1000ms: Long-Hold Gesture -> Log Sunscreen SPF!
    if (touchStable && rawActive && !touchLongHandled && (now - touchDownMs >= 1000)) {
      touchLongHandled = true;
      tapPendingCount = 0;
      sunElapsedMin = 0;
      spfLogged = true;
      lastMinuteMs = now;
      sunSeq++;
      lastTouchGesture = "hold_spf";
      triggerHapticPulses(3, 55);
      triggerAudioPip(90, 2600);
    }

    // Falling edge: Finger lifted
    if (!rawActive && touchStable) {
      touchStable = false;
      if (!touchLongHandled) {
        // If an Edge Safety Alert is ringing, immediate single-tap dismisses it!
        if (alertLatched && alertActive) {
          alertLatched = false;
          ackSeq++;
          lastTouchGesture = "ack_alert";
          setBuzzerRaw(false);
          triggerHapticPulses(1, 60);
          tapPendingCount = 0;
        } else {
          tapPendingCount++;
          lastTapReleaseMs = now;
        }
      }
    }
  }

  // Resolve Single Tap vs Double Tap window (280 ms)
  if (tapPendingCount > 0 && !touchStable) {
    if (tapPendingCount >= 2) {
      tapPendingCount = 0;
      setSkinProfile(skinType, !sensitiveSkin);
      sensSeq++;
      lastTouchGesture = sensitiveSkin ? "double_sens_on" : "double_sens_off";
      triggerHapticPulses(2, 50);
      triggerAudioPip(70, sensitiveSkin ? 2500 : 1750);
      evaluateEdgeSafety();
    } else if (now - lastTapReleaseMs >= 280) {
      tapPendingCount = 0;
      watchScreen = (watchScreen + 1) % NUM_SCREENS;
      scrSeq++;
      lastTouchGesture = "tap_next";
      triggerAudioPip(22, 2000);
    }
  }
}

// ======================================================================================
//  0.96" YELLOW + BLUE SSD1306 OLED RENDERER (128x64)
//  - Strict Zone Split:
//      y = 0..15  (Top 16px = Physical YELLOW OLED Phosphor -> Status & Battery Bar)
//      y = 16..63 (Bottom 48px = Physical BLUE OLED Phosphor -> Main Watch Cards)
// ======================================================================================
void drawBatteryGlyph(int x, int y, int pct) {
  display.drawRect(x, y, 18, 9, SSD1306_WHITE);
  display.fillRect(x + 18, y + 2, 2, 5, SSD1306_WHITE);
  int fillW = constrain((int)roundf((pct / 100.0f) * 14.0f), 0, 14);
  if (fillW > 0) display.fillRect(x + 2, y + 2, fillW, 5, SSD1306_WHITE);
}

// Constrain every OLED text line to the 128-pixel row. Long text ends in '~'
// rather than wrapping into another row. The default font uses 6 x 8 pixels.
void oledLine(int x, int y, int size, String text) {
  if (x < 0 || y < 0 || x >= SCREEN_WIDTH || size < 1 || y + 8 * size > SCREEN_HEIGHT) return;
  const int available = (SCREEN_WIDTH - x) / (6 * size);
  if (available <= 0) return;
  if ((int)text.length() > available) text = text.substring(0, available - 1) + "~";
  display.setTextSize(size);
  display.setCursor(x, y);
  display.print(text);
}

void drawYellowTopBar() {
  oledLine(0, 3, 1, alertActive ? "!AURA" : "AURA");
  String badge = simOverride ? "[TEST]" : sensitiveSkin ? "[SENS]" : standaloneSim ? "[EDGE]" :
                 !buzEnabled ? "[MUTE]" : scoreValid ? ("S:" + String(auraScore)) : "S:--";
  oledLine(32, 3, 1, badge);
  const String bp = batValid ? (String(batPct) + "%") : "--%";
  oledLine(106 - bp.length() * 6, 3, 1, bp);
  drawBatteryGlyph(108, 2, batValid ? batPct : 0);
}

void renderOledWatch() {
  if (!oledOk) return;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);
  drawYellowTopBar();
  const float tempF = tempC * 1.8f + 32.0f; // Display conversion only; tempC/thresholds stay in C.
  switch (watchScreen) {
    case 0: { // Home + composite score
      oledLine(0, 19, 2, scoreValid ? String(auraScore) : String("--"));
      oledLine(42, 19, 1, "/100");
      oledLine(42, 28, 1, auraBand);
      oledLine(0, 41, 1, "HR:" + (hasHr() ? String(hrBpm) : String("--")) +
                         " SpO2:" + (hasSpo2() ? String(spo2Pct) : String("--")) + "%");
      oledLine(0, 53, 1, "UV:" + String(uvIndex) + " T:" +
          (hasTemp() ? (String(tempC, 1) + "C/" + String(tempF, 1) + "F") : String("--C/--F")));
      break;
    }
    case 1: { // Heart rate (existing value, validity and thresholds unchanged)
      oledLine(0, 18, 1, "HEART RATE (MAX30102)");
      const String bpm = hasHr() ? String(hrBpm) : String("--");
      oledLine(0, 30, 2, bpm);
      oledLine(bpm.length() * 12 + 6, 38, 1, "BPM");
      String hint;
      if (!hasHr()) hint = maxOk ? "Waiting for contact" : "MAX30102 not found";
      else if (hrBpm > thHrHigh || hrBpm < thHrLow) hint = "! Limit " + String(thHrLow) + "-" + String(thHrHigh);
      else hint = "Pulse OK (" + String(thHrLow) + "-" + String(thHrHigh) + ")";
      oledLine(0, 53, 1, hint);
      break;
    }
    case 2: { // SpO2 (existing value, validity and thresholds unchanged)
      oledLine(0, 18, 1, "BLOOD OXYGEN (SpO2)");
      oledLine(0, 30, 2, (hasSpo2() ? String(spo2Pct) : String("--")) + "%");
      String hint;
      if (!hasSpo2()) hint = maxOk ? "Waiting for contact" : "MAX30102 not found";
      else if (spo2Pct < thSpo2) hint = "! HYPOXIA < " + String(thSpo2) + "%";
      else hint = "Saturation Nominal";
      oledLine(0, 53, 1, hint);
      break;
    }
    case 3: { // Temperature: show both units without changing the C-based alert.
      oledLine(0, 18, 1, "THERMAL (DS18B20)");
      const String c = hasTemp() ? String(tempC, 1) : String("--");
      oledLine(0, 30, 2, c);
      oledLine(c.length() * 12 + 3, 38, 1, "C");
      String detail;
      if (!hasTemp()) detail = "--F SENSOR UNAVAILABLE";
      else if (tempC > thTemp) detail = String(tempF, 1) + "F !HIGH>" + String(thTemp, 1) + "C";
      else detail = String(tempF, 1) + "F " + (dsSensorFound ? "R:" : "S:") +
                    String(rawTempC, 1) + " M:" + String(thTemp, 1);
      oledLine(0, 53, 1, detail); // R/S = raw/sim, M = C threshold.
      break;
    }
    case 4: { // UV and SPF
      oledLine(0, 18, 1, "UV " + (skinType ? ("TYPE " + String(skinType)) : String("TYPE ?")) + (sensitiveSkin ? " SENS" : " STD"));
      oledLine(0, 30, 2, "UV " + String(uvIndexFloat, 1));
      const int rem = max(0, sunLimitMinutes() - sunElapsedMin);
      oledLine(0, 53, 1, !spfLogged ? "SPF:HOLD TO LOG" : rem == 0 ? "SPF:REAPPLY NOW!" : ("SPF:" + String(rem) + "m HOLD=LOG"));
      break;
    }
    case 5: { // Battery and link
      oledLine(0, 18, 1, "TP4056 BATTERY / LINK");
      const String pct = (batValid ? String(batPct) : String("--")) + "%";
      oledLine(0, 30, 2, pct);
      oledLine(max(50, (int)pct.length() * 12 + 2), 38, 1,
          batValid ? (String(batVolts, 2) + "V") : batterySenseEnabled ? "NO READING" : "SENSE OFF");
      oledLine(0, 53, 1, "WiFi:" + WiFi.softAPIP().toString());
      break;
    }
    case 6: { // Existing alert content, bounded to individual rows.
      if (alertActive) {
        oledLine(0, 18, 1, alertUrgent ? "!! URGENT EDGE ALERT" : "! SAFETY ADVISORY");
        String title = topAlertTitle;
        if (activeAlertCount > 1) title += " (+" + String(activeAlertCount - 1) + ")";
        oledLine(0, 30, 1, title);
        oledLine(0, 42, 1, topAlertDetail);
        oledLine(0, 54, 1, alertLatched ? ">> Tap Touch to ACK" : "Acked - Monitoring");
      } else {
        oledLine(0, 26, 2, scoreValid ? "ALL CLEAR" : "NO DATA");
        oledLine(0, 53, 1, scoreValid ? "Edge Safety Active" : "Check vital sensors");
      }
      break;
    }
    case 7: // Phone-synchronized clock
      oledLine(0, 18, 1, "TIME / PHONE SYNC");
      oledLine(0, 31, 2, formattedWatchClock());
      oledLine(0, 54, 1, clockValid ? "Re-sync after reset" : "Open phone web app");
      break;
    case 8: // AQI placeholder only; no sensor reading.
      oledLine(0, 18, 1, "AIR QUALITY / AQI");
      oledLine(0, 30, 2, "COMING");
      oledLine(0, 53, 1, "SOON / NO AQI SENSOR");
      break;
  }
  display.display();
}

// ======================================================================================
//  TWO-WAY TELEMETRY JSON & COMMAND PARSER (Wi-Fi HTTP + USB Web Serial)
// ======================================================================================
String buildTelemetryJson() {
  String j = "{";
  j += "\"fw\":\"project-aura-c3-3.0\",";
  j += "\"mcu\":\"ESP32-C3-SuperMini\",";
  j += "\"hr\":" + (hasHr() ? String(hrBpm) : String("null")) + ",";
  j += "\"spo2\":" + (hasSpo2() ? String(spo2Pct) : String("null")) + ",";
  j += "\"temp\":" + (hasTemp() ? String(tempC, 1) : String("null")) + ",";
  j += "\"tempRaw\":" + (tempValid ? String(rawTempC, 1) : String("null")) + ",";
  j += "\"uv\":" + String(uvIndex) + ",";
  j += "\"uvFloat\":" + String(uvIndexFloat, 1) + ",";
  j += "\"uvMv\":" + String(uvMilliVolts) + ",";
  j += "\"bat\":" + (batValid ? String(batPct) : String("null")) + ",";
  j += "\"batV\":" + (batValid ? String(batVolts, 2) : String("null")) + ",";
  j += "\"batAdcMv\":" + (batterySenseEnabled && !simOverride && batAdcMv >= 0 ? String(batAdcMv) : String("null")) + ",";
  j += "\"batHw\":" + String(batHwDetected ? "true" : "false") + ",";
  j += "\"batSense\":" + String(batterySenseEnabled ? "true" : "false") + ",";
  j += "\"batSenseSaveOk\":" + String(batterySenseSaveOk ? "true" : "false") + ",";
  j += "\"score\":" + (scoreValid ? String(auraScore) : String("null")) + ",";
  j += "\"band\":\"" + String(auraBand) + "\",";
  j += "\"heatPred\":" + String(heatStrainPred ? "true" : "false") + ",";
  j += "\"hrValid\":" + String(hasHr() ? "true" : "false") + ",";
  j += "\"spo2Valid\":" + String(hasSpo2() ? "true" : "false") + ",";
  j += "\"tempValid\":" + String(hasTemp() ? "true" : "false") + ",";
  j += "\"tempOffsetOn\":" + String(useBodyOffset ? "true" : "false") + ",";
  j += "\"uvGain\":" + String(uvGain, 2) + ",";
  j += "\"maxOk\":" + String(maxOk ? "true" : "false") + ",";
  j += "\"finger\":" + String(fingerDetected ? "true" : "false") + ",";
  j += "\"dsOk\":" + String((dsSensorFound && tempValid) ? "true" : "false") + ",";
  j += "\"oledOk\":" + String(oledOk ? "true" : "false") + ",";
  j += "\"touch\":" + String(touchNow ? "true" : "false") + ",";
  j += "\"gesture\":\"" + lastTouchGesture + "\",";
  j += "\"sens\":" + String(sensitiveSkin ? "true" : "false") + ",";
  j += "\"skin\":" + String(skinType) + ",";
  j += "\"skinSaveOk\":" + String(skinSaveOk ? "true" : "false") + ",";
  j += "\"skinSaved\":" + String(skinSaved ? "true" : "false") + ",";
  j += "\"clockValid\":" + String(clockValid ? "true" : "false") + ",";
  j += "\"clock\":\"" + formattedWatchClock() + "\",";
  j += "\"tzMin\":" + String(clockTzMinutes) + ",";
  j += "\"sensSeq\":" + String(sensSeq) + ",";
  j += "\"standalone\":" + String(standaloneSim ? "true" : "false") + ",";
  j += "\"th\":{\"hl\":" + String(thHrLow) + ",\"hh\":" + String(thHrHigh) + ",\"sp\":" + String(thSpo2) + ",\"tp\":" + String(thTemp, 1) + "},";
  j += "\"sun\":" + String(sunElapsedMin) + ",";
  j += "\"spfLogged\":" + String(spfLogged ? "true" : "false") + ",";
  j += "\"exposureMin\":" + String(exposureMinutes, 2) + ",";
  j += "\"uvDose\":" + String(uvIndexMinutes, 2) + ",";
  j += "\"sunSeq\":" + String(sunSeq) + ",";
  j += "\"snd\":" + String(buzEnabled ? "true" : "false") + ",";
  j += "\"vib\":" + String(vibEnabled ? "true" : "false") + ",";
  j += "\"buzMode\":" + String(buzMode) + ",";
  j += "\"invBuz\":" + String(invBuz ? "true" : "false") + ",";
  j += "\"invTouch\":" + String(invTouch ? "true" : "false") + ",";
  j += "\"buzOn\":" + String(buzCurrentlyOn ? "true" : "false") + ",";
  j += "\"vibOn\":" + String(vibCurrentlyOn ? "true" : "false") + ",";
  j += "\"simOverride\":" + String(simOverride ? "true" : "false") + ",";
  j += "\"scr\":" + String(watchScreen) + ",";
  j += "\"scrSeq\":" + String(scrSeq) + ",";
  j += "\"ackSeq\":" + String(ackSeq) + ",";
  j += "\"alertActive\":" + String(alertActive ? "true" : "false") + ",";
  j += "\"alertLatched\":" + String(alertLatched ? "true" : "false") + ",";
  j += "\"alertTitle\":\"" + topAlertTitle + "\",";
  j += "\"alertDetail\":\"" + topAlertDetail + "\",";
  j += "\"raw\":{\"ir\":" + String(latestIr) + ",\"red\":" + String(latestRed) + ",\"uvMv\":" + String(uvMilliVolts) + "}";
  j += "}";
  return j;
}

void applyKeyValue(const String& key, const String& val) {
  if (key == "scr") watchScreen = constrain(val.toInt(), 0, NUM_SCREENS - 1);
  else if (key == "ack" && val == "1") { alertLatched = false; setBuzzerRaw(false); vibPulsesLeft = 0; setVibMotorRaw(false); }
  else if (key == "sens") setSkinProfile(skinType, val == "1" || val == "true");
  else if (key == "skin") { long long n; if (parseWholeNumber(val, n) && n >= 0 && n <= 6) setSkinProfile((uint8_t)n, sensitiveSkin); }
  else if (key == "epoch") setPhoneEpoch(val);
  else if (key == "tzMin") setPhoneOffset(val);
  else if (key == "snd") {
    buzEnabled = (val == "1" || val == "true");
    if (!buzEnabled) setBuzzerRaw(false);
  }
  else if (key == "vib") {
    vibEnabled = (val == "1" || val == "true");
    if (!vibEnabled) setVibMotorRaw(false);
  }
  else if (key == "buzMode") { buzMode = constrain(val.toInt(), 0, 1); setBuzzerRaw(false); }
  else if (key == "invBuz")  { invBuz = (val == "1" || val == "true"); setBuzzerRaw(false); }
  else if (key == "invTouch") invTouch = (val == "1" || val == "true");
  else if (key == "testBuz" && val == "1") {
    bool prev = buzEnabled; buzEnabled = true;
    triggerAudioPip(180, 2450);
    buzEnabled = prev;
  }
  else if (key == "testVib" && val == "1") {
    bool prev = vibEnabled; vibEnabled = true;
    triggerHapticPulses(2, 90);
    vibEnabled = prev;
  }
  else if (key == "sunReset" && val == "1") { sunElapsedMin = 0; spfLogged = true; lastMinuteMs = millis(); }
  else if (key == "sun") { sunElapsedMin = constrain(val.toInt(), 0, 240); spfLogged = true; lastMinuteMs = millis(); }
  else if (key == "expReset" && val == "1") { exposureMinutes = 0; uvIndexMinutes = 0; }
  else if (key == "batSense") {
    bool requested = (val == "1" || val == "true");
    // Never write flash on every poll: save only when changed or a failed save is retried.
    if (requested != batterySenseEnabled || !batterySenseSaveOk) {
      if (requested != batterySenseEnabled) resetBatterySampler();
      batterySenseEnabled = requested;
      batterySenseSaveOk = saveBatterySenseSetting(requested);
    }
  }
  else if (key == "bat") simBat = constrain(val.toInt(), 0, 100); // ONLY visible when simOverride is on
  else if (key == "uvGain") uvGain = constrain(val.toFloat(), 0.5f, 8.0f);
  else if (key == "useOffset") useBodyOffset = (val == "1" || val == "true");
  else if (key == "rezero" && val == "1") { tempOffset = 36.8f - rawTempC; useBodyOffset = true; }
  else if (key == "standalone") standaloneSim = (val == "1" || val == "true");
  else if (key == "simOverride") {
    bool next = (val == "1" || val == "true");
    if (simOverride != next) resetBatterySampler();
    if (simOverride && !next) {
      hrValid = spo2Valid = tempValid = batValid = false;
      spfLogged = false; sunElapsedMin = 0; lastMinuteMs = millis(); // Demo timer is not real SPF history.
    }
    simOverride = next;
  }
  else if (key == "simHr")   simHr = constrain(val.toInt(), 35, 200);
  else if (key == "simSpo2") simSpo2 = constrain(val.toInt(), 80, 100);
  else if (key == "simTemp") simTemp = constrain(val.toFloat(), 20.0f, 43.0f);
  else if (key == "simUv")   simUv = constrain(val.toInt(), 0, 12);
  else if (key == "hl") thHrLow  = constrain(val.toInt(), 35, 95);
  else if (key == "hh") thHrHigh = constrain(val.toInt(), 90, 210);
  else if (key == "sp") thSpo2   = constrain(val.toInt(), 80, 99);
  else if (key == "tp") thTemp   = constrain(val.toFloat(), 20.0f, 43.0f);
}

void parseQueryCommandString(String qs) {
  qs.trim();
  int start = 0;
  while (start < (int)qs.length()) {
    int amp = qs.indexOf('&', start);
    if (amp < 0) amp = qs.length();
    String pair = qs.substring(start, amp);
    int eq = pair.indexOf('=');
    if (eq > 0) {
      applyKeyValue(pair.substring(0, eq), pair.substring(eq + 1));
    }
    start = amp + 1;
  }
  evaluateEdgeSafety();
}

void pollUsbSerialCommands() {
  static String line;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n') {
      line.trim();
      if (line.startsWith("CMD:")) parseQueryCommandString(line.substring(4));
      line = "";
    } else if (c != '\r') {
      if (line.length() < 400) line += c;
      else line = "";
    }
  }
}

void addCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
}

// Gzip-compressed phone HTML is served directly from flash; no cloud required.

void setupHttpServer() {
  server.on("/", HTTP_GET, []() {
    server.sendHeader("Cache-Control", "no-store");
    server.sendHeader("Content-Encoding", "gzip");
    server.send_P(200, PSTR("text/html; charset=utf-8"), reinterpret_cast<PGM_P>(AURA_PHONE_HTML_GZ), sizeof(AURA_PHONE_HTML_GZ));
  });

  server.on("/status", HTTP_OPTIONS, []() { addCorsHeaders(); server.send(204); });
  server.on("/status", HTTP_GET, []() {
    addCorsHeaders();
    server.send(200, "application/json", buildTelemetryJson());
  });

  server.on("/cmd", HTTP_OPTIONS, []() { addCorsHeaders(); server.send(204); });
  server.on("/cmd", HTTP_GET, []() {
    for (int i = 0; i < server.args(); i++) {
      applyKeyValue(server.argName(i), server.arg(i));
    }
    evaluateEdgeSafety();
    addCorsHeaders();
    server.send(200, "application/json", buildTelemetryJson());
  });

  server.begin();
}

// ======================================================================================
//  SETUP & MAIN LOOP
// ======================================================================================
void setup() {
  Serial.begin(115200);
  restoreBatterySenseSetting(); // Load wiring confirmation before the first ADC reading.
  restoreSkinProfile();         // Restore the last saved skin type and sensitivity.

  // Configure GPIO inputs & actuators
  pinMode(PIN_TOUCH, INPUT);           // TTP223R actively drives HIGH/LOW
  pinMode(PIN_VIB_MOTOR, OUTPUT);
  digitalWrite(PIN_VIB_MOTOR, LOW);
  pinMode(PIN_BUZZER, OUTPUT);
  setBuzzerRaw(false);

  // Configure ESP32-C3 Calibrated ADC1 Channels (0 - 2500 mV @ 11dB)
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_UV_ADC, ADC_11db);
  analogSetPinAttenuation(PIN_BAT_ADC, ADC_11db);

  // Initialize requested I2C bus: GPIO 8/9 are strapping pins; verify board boot behavior.
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.setClock(400000);

  // 1. Probe the OLED: display.begin() alone allocates memory, not an I2C presence test.
  Wire.beginTransmission(0x3C);
  bool oledPresent = (Wire.endTransmission() == 0);
  if (!oledPresent) {
    Wire.beginTransmission(0x3D);
    if (Wire.endTransmission() == 0) { oledAddr = 0x3D; oledPresent = true; }
  }
  oledOk = oledPresent && display.begin(SSD1306_SWITCHCAPVCC, oledAddr, true, false); // Keep custom Wire pins.
  if (oledOk) {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(10, 3);
    display.print("PROJECT AURA v3.0"); // Yellow top band!
    display.setCursor(4, 22);
    display.print("Adv. UV & Risk-Pred.");
    display.setCursor(4, 36);
    display.print("ESP32-C3 SuperMini");
    display.setCursor(4, 50);
    display.print("Booting sensors...");
    display.display();
  }

  // 2. Initialize MAX30102 Heart Rate & Pulse Oximeter on same I2C bus (0x57)
  if (particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    maxOk = true;
    byte ledBrightness = 0x24; // Balanced Red/IR current for finger/wrist PPG
    byte sampleAverage = 4;
    byte ledMode       = 2;    // Red + IR (HR + SpO2)
    int  sampleRate    = 400;
    int  pulseWidth    = 411;
    int  adcRange      = 4096;
    particleSensor.setup(ledBrightness, sampleAverage, ledMode, sampleRate, pulseWidth, adcRange);
  }

  // 3. Initialize DS18B20 Temperature Sensor on GPIO 3 (+ 10k pull-up to 3V3)
  ds18b20.begin();
  dsSensorFound = (ds18b20.getDeviceCount() > 0);
  if (dsSensorFound) {
    ds18b20.setResolution(10);
    ds18b20.setWaitForConversion(false);
    ds18b20.requestTemperatures();
    delay(200);
    float initT = ds18b20.getTempCByIndex(0);
    if (initT > -20.0f && initT < 70.0f) {
      rawTempC = initT;
      tempC = roundf(initT * 10.0f) / 10.0f;
      tempValid = true;
    }
    ds18b20.requestTemperatures();
  }
  lastMinuteMs = lastExposureMs = millis();

  // 4. Start Wi-Fi SoftAP + ESP32-C3 SuperMini RF Stability Fix (8.5 dBm TX power)
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  WiFi.setTxPower(WIFI_POWER_8_5dBm); // Lower RF power; range and supply stability still need testing.
  setupHttpServer();

  // Boot confirmation haptic tap + gentle chime
  triggerHapticPulses(1, 65);
  triggerAudioPip(80, 2300);
}

void loop() {
  server.handleClient();
  pollUsbSerialCommands();
  pollTouchGestures();
  pollMax30102();
  pollAnalogAndTemp();
  evaluateEdgeSafety();
  serviceActuators();

  unsigned long now = millis();
  if (now - lastOledMs >= 160) {
    lastOledMs = now;
    renderOledWatch();
  }
  if (now - lastSerialMs >= 200) {
    lastSerialMs = now;
    Serial.println(buildTelemetryJson());
  }
}
