# Project AURA — updated hardware guide

The earlier ESP32 DevKit V1 / potentiometer / LDR / SH1106 circuit has been superseded by your **ESP32-C3 SuperMini** Project AURA build.

Please use **[PROJECT_AURA_HARDWARE_GUIDE.md](PROJECT_AURA_HARDWARE_GUIDE.md)** for the current pin map, LiPo charging and boost-converter safety, OLED and sensor wiring, additional parts needed for battery sensing and motor drive, firmware upload, and Wi-Fi/USB connection instructions.

**Important:** the selectable boost may be set to 12 V. Configure and **measure 5 V before connecting the ESP32**. Turn the battery switch OFF before ESP32 USB connection and while charging. The TP4056 charges the battery but cannot provide percentage on its own: the ESP32 estimates it from protected, switched TP4056 output voltage through two additional 10 kΩ divider resistors; the single 10 kΩ in the BOM is used by the DS18B20. The coin motor requires a driver and flyback diode; do not connect it directly to a GPIO. Project AURA is an unvalidated demonstration, not a medical device.
