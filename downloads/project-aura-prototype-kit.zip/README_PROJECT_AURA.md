# Project AURA

**Advanced UV & Risk-prediction Assistant** — interactive wearable + companion app demo for the ESP32-C3 SuperMini.

## Start here

1. Open **`Project AURA – Advanced UV & Risk-prediction Assistant.html`** for the Companion demo, or **`project_aura_dashboard.html`** for Studio. Both work without any hardware in simulation mode. The old FizzBand HTML filenames have also been updated to the new project.
2. Read **`PROJECT_AURA_HARDWARE_GUIDE.md`** before wiring power, battery sensing, the motor or sensors.
3. Open **`project_aura_esp32c3/project_aura_esp32c3.ino`** in Arduino IDE 2.x. Select **ESP32C3 Dev Module**, enable **USB CDC On Boot**, install the libraries listed in the guide, and upload.
4. For Wi-Fi, join **Project-AURA** (demo password `12345678`). Run `python3 aura_bridge.py`, open `http://localhost:8765/?bridge=1`, then click **Connect Wi-Fi**. Alternatively use USB Web Serial in a compatible desktop browser. Download/open outside the in-chat preview for hardware access.

**Orange + black theme:** both demos have been restyled; the watch's OLED remains yellow + blue to match its fixed-color display.

**TP4056 battery:** the TP4056 charges the battery but does not output a battery percentage. AURA estimates percentage from the protected, switched TP4056 output using GPIO 1 and **two additional 10 kΩ divider resistors**. After verifying the circuit, enable the estimate in Device controls; that confirmation is saved on the ESP32. With the safe setup, switch the load OFF while charging, so the wearable does not display a live % during charging. See the hardware guide for the exact wiring.

**Hardware essentials:** the selectable boost can default to 12 V—configure it for 5 V and verify with a multimeter before connecting the ESP32. Turn the battery switch OFF before ESP32 USB or TP4056 charging. The coin motor needs a proper transistor/MOSFET driver and flyback diode. The ACEBOTT product listing has conflicting output-voltage specifications: measure and verify its output before connecting it to an ADC pin. See the guide.

The score, UV reading, SpO₂ and alerts are **experimental demo estimates**, not medical measurements or sun-safety guarantees. Missing biometric, temperature or battery data is displayed as unavailable, not fabricated. OS-level notifications are optional and only while the page is running; no background push service or BLE implementation is included. Compiled and browser-tested with simulated interfaces; actual hardware, wiring, sensor calibration and browser permissions must be verified on your own components.

## Verification

The updated v2.1 sketch compiled for ESP32C3 Dev Module with USB CDC enabled using Espressif Arduino core 3.3.12. Both orange-and-black demos were exercised in a browser, including gestures, alerts, scoring, offline simulation, responsive layout, and mocked Wi-Fi and USB serial telemetry/commands. TP4056 opt-in and battery-estimate displays were tested against simulated packets; the battery curve and saved-setting logic were unit-tested with simulated storage. No physical board or sensors were available for testing, so actual wiring, storage persistence, RF, battery measurement, sensor performance, alert hardware, and calibration must be verified on your build.
