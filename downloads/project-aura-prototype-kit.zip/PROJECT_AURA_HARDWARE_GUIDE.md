# Project AURA — hardware, firmware & demo guide

**Advanced UV & Risk-prediction Assistant** · ESP32-C3 SuperMini · prototype build

> **Prototype, not a medical device or a certified UV meter.** The SpO₂ algorithm, heart-rate detection, UV conversion, temperature interpretation, score, skin profiles, exposure budget and alerts are **unvalidated demonstration heuristics**. Do not use them to diagnose, decide treatment, judge a safe sun-exposure duration, or replace sunscreen instructions or professional advice. A MAX30102 reading requires good optical contact and may be inaccurate. DS18B20 reports sensor/skin temperature, **not core body temperature**. The UV input cannot reliably detect a disconnected sensor. Never deliberately expose anyone to strong UV for a demo: use the explicitly marked simulation mode.

## 1. What is included

| File | Purpose |
|---|---|
| `project_aura_esp32c3/project_aura_esp32c3.ino` | Arduino IDE sketch for the ESP32-C3 SuperMini; keep the sketch in its same-named folder. A duplicate `.ino` also sits at the top level for convenience. |
| `Project AURA – Advanced UV & Risk-prediction Assistant.html` | Standalone Companion-style watch + mobile demo. |
| `project_aura_dashboard.html` | Standalone Studio-style watch + mobile demo, with the same features and hardware protocol. |
| `aura_bridge.py` | Optional standard-library Python Wi-Fi bridge that serves either HTML file on the same computer. |
| `FizzBand – Smart UV & Health Safety Companion.html`, `fizzband_dashboard.html` | The old HTML filenames have also been updated to AURA, so existing bookmarks do not open the obsolete DevKit prototype. |
| `fizzband_esp32_demo.ino` | Legacy filename, now mirrored to the C3/AURA sketch so it cannot accidentally upload the obsolete DevKit build. |

Both HTML prototypes now use an **orange-and-black** interface. The simulated watch's pixels remain yellow and blue because your chosen two-color OLED has physically fixed yellow and blue zones; it cannot be recolored by software.

The HTML works without hardware or internet in **software simulation**. The virtual mobile screen is a web-page mock-up, not a native mobile app. Its alerts are in-page banners; optional browser notifications work only with permission while the page is running and only where the browser supports them. It is **not** cloud push and does not deliver notifications after the page is closed. The App Sync toggle demonstrates a frozen phone snapshot; it does not create a real BLE connection. The actual hardware bridge is Wi-Fi or USB serial, not BLE. Edge rules continue on the MCU without the page.

## 2. Your parts and additional parts

Your BOM: ESP32-C3 SuperMini; 0.96-inch, yellow/blue 128×64 **4-pin I²C SSD1306** OLED; black MAX30102 module; DS18B20; one 10 kΩ resistor; red TTP223R 1-channel touch module; coin vibration motor; mini buzzer; 3.7 V 523450 single-cell LiPo; TP4056 USB-C charger; 3-pin slide switch; selectable mini DC-DC boost; ACEBOTT QB104 UV sensor.

**Additional parts necessary for the complete build:**

- **For the TP4056-based battery estimate:** two more **10 kΩ** resistors for the GPIO 1 voltage divider. The single 10 kΩ in your BOM is already used as the DS18B20 pull-up. A small 100 nF capacitor from GPIO 1 to GND is optional for ADC smoothing. The ESP32 reads cell voltage through the TP4056 module's protected output; the charger does not itself calculate percentage. A proper fuel-gauge IC would give a better estimate than voltage alone.
- **For the motor:** a 3.3 V-gate-compatible N-channel MOSFET (for example AO3400A or a suitable equivalent), a gate resistor (about 100–220 Ω), a gate-to-ground pull-down (about 100 kΩ) and a flyback diode (for example 1N5819). Choose a MOSFET and diode rated for the motor's **startup/stall current**, not merely its running current. Do not wire the motor directly to the GPIO.
- **For the buzzer, if it is an electromagnetic or higher-current part:** a suitably rated driver and, for an inductive load, flyback diode. A logic-input buzzer module can be driven from GPIO 10 only if its signal input accepts 3.3 V and the module is correctly powered. A low-current passive piezo may connect directly only if its data sheet confirms the ESP32 pin's voltage and current limits. Your buzzer type was not specified; inspect its markings/data sheet first.
- Jumper wires/breadboard, suitable enclosure/strain relief and a **multimeter**. If the TP4056 board and cell do not already provide proper single-cell protection, add a compatible protection board/protected cell. The charger IC alone is not battery protection.

## 3. Pin map — GPIO numbers, not header positions

Use the labels on your specific SuperMini board; variants can differ. All modules and power supplies must share GND. Power logic modules from **3V3**, not the 5 V boost rail.

| Module | Connection to ESP32-C3 SuperMini | Notes |
|---|---|---|
| ACEBOTT QB104 UV | VCC → **3V3**, GND → GND, analog signal → **GPIO 0** | Verify output voltage with a meter before connection; see §6. |
| TP4056 battery-voltage divider | Protected TP4056 **OUT+ → slide switch → 10 kΩ → midpoint → 10 kΩ → OUT−/GND**; midpoint → **GPIO 1** | Add two resistors. Enable sensing only after wiring and measuring. This gives an approximate %; never connect cell + directly to GPIO 1. |
| DS18B20 | VDD → **3V3**, GND → GND, DATA → **GPIO 3** | The supplied **10 kΩ** goes from DATA/GPIO 3 to 3V3. Use three-wire powered mode; do not use parasite power. |
| TTP223R (red) | VCC → **3V3**, GND → GND, SIG → **GPIO 4** | Assumes default momentary, active-HIGH mode, AB=00. Verify module configuration and pin labels. |
| Coin motor driver | **GPIO 5** → gate resistor → MOSFET gate; common GND | MOSFET/diode circuit in §5; motor supply must match its own rating. |
| OLED + MAX30102 | Both SDA → **GPIO 6**, both SCL → **GPIO 7**, both GND → GND | Shared I²C. OLED VCC and MAX module VIN → 3V3 only if the specific modules support it; check labels and pull-up voltages. OLED normally 0x3C/0x3D; MAX30102 0x57. |
| Buzzer signal/driver | **GPIO 10** | Correctly rated piezo or driver/module; choose passive tone or active DC in Device controls. |
| Onboard blue LED | GPIO 8, active LOW on many SuperMinis | Board-dependent; used by firmware. |
| Onboard BOOT button | GPIO 9, active LOW | Backup touch gesture input. Holding BOOT during reset can enter download mode; GPIO 9 is a strapping pin. |

GPIO 2, 8 and 9 have boot-strapping considerations. GPIO 18/19 are **not** the old DevKit's touch/buzzer pins here; the old FizzBand hardware mapping is superseded. Do not connect 5 V signal lines to ESP32-C3 GPIO. Some MAX30102 breakouts have different regulator and I²C pull-up arrangements: **check the specific board** so SDA/SCL never exceed 3.3 V. A bare MAX30102 chip does not take a raw 3.3 V logic supply the same way a regulated breakout may.

The DS18B20 is commonly read with a 4.7 kΩ pull-up; the supplied 10 kΩ may work for short wiring but is not guaranteed. If readings fail, verify the probe pinout and replace the pull-up with 4.7 kΩ. Do not assume waterproof-probe wire colors without checking the seller's pinout.

## 4. Power path — read before connecting the ESP32

**Important:** listings for visually similar boost boards differ. Several suppliers describe A=0/B=0 as 5 V and A=1/B=1 as a 12 V default, but the exact board must be verified. **Never trust the solder-pad setting alone.** Disconnect the ESP32 and peripherals, configure the boost, and measure the output with a multimeter before connection.

Typical wiring when you have a **protected TP4056 board with B+/B− and separate OUT+/OUT− terminals**:

```text
                 3.7 V single-cell LiPo 523450
                    +                 −
                    │                 │
               TP4056 B+         TP4056 B−
                    │    protected TP4056    │
               TP4056 OUT+             TP4056 OUT− ───────────── common GND
                    │
          SPDT slide switch, two terminals used
             (verify common with a meter)
                    │ switched battery positive
                    ├───────── Boost IN+
                    └── 10 kΩ ──●── 10 kΩ ── common GND   [extra battery divider]
                                 └───────────── GPIO 1

          common GND ─────────── Boost IN− and ESP32 GND
          Boost OUT+ ─────────── ESP32 5V / VIN  [ONLY after measured 5.0 V]
          Boost OUT− ─────────── ESP32 GND
```

1. With all power disconnected, set the boost for **5 V**. On the commonly sold A/B variant, this means both A and B solder links **open** (A=0, B=0); some ship set to **12 V**. Confirm your own board's markings and supplier information.
2. With the ESP32 disconnected, apply the battery to the protected circuit and switch ON. Measure boost OUT+ to OUT−: approximately **5.0 V** with correct polarity. Also check under a suitable load. If it is 8, 9, 12 V or unstable, **do not connect it**. Confirm the specific SuperMini's `5V` pin is intended as a 5 V input.
3. The common terminal of a 3-pin slide switch is *often* the middle pin, but not always. Use continuity mode to identify it; connect common and one switched outer terminal, leave the remaining terminal unconnected. Never bridge battery positive to GND with the switch.
4. Connect ESP32 5V and GND only after checking voltage/polarity. The SuperMini's onboard regulator supplies 3V3; never apply the boost's 5 V output to 3V3 or a GPIO.
5. **Power-source isolation:** turn the battery slide switch **OFF** before connecting the ESP32's USB-C for flashing or Web Serial. For the simplest safe procedure, also unplug the TP4056 charger USB cable during flashing. Avoid feeding the USB 5 V rail and external boost 5 V simultaneously; board variants may backfeed.
6. **Charging:** turn the load switch **OFF** and unplug the ESP32 USB, then use the TP4056 USB-C to charge. Ordinary TP4056 modules generally do **not** have true power-path/load sharing; powering the load while charging can interfere with charge termination. Do not assume every TP4056 board has protection. Verify correct polarity and a protected cell/board, and use a charge current within the cell manufacturer's specification. Many TP4056 boards are set near **1 A**, which may be too high for a small 523450 cell. Inspect the PROG resistor and the cell's rated capacity/current; use a suitable lower setting if needed. Stop if the cell or charger overheats, swells, or is damaged. Never leave experimental LiPo charging unattended.

### TP4056 battery percentage: what it can and cannot do

The **TP4056 is a charger, not a battery-percentage sensor**. Its `CHRG` and `STDBY` pins / LEDs indicate charge or termination status; they do not provide state-of-charge %. This firmware does not read those charge-status pins. Instead, the ESP32 measures the protected TP4056 output's **battery voltage** using GPIO 1, and estimates a percentage from that voltage. A one-cell LiPo is nominally 3.7 V, about 4.2 V when fully charged; voltage is not a precise or linear state-of-charge measurement.

With **all power disconnected**, wire the divider exactly as shown below. This requires **two additional 10 kΩ resistors**; use the existing 10 kΩ separately for the DS18B20. Read module pad labels carefully.

```text
      TP4056 protected OUT+
              │
         slide switch
              │ switched positive (also goes to boost IN+)
              ├── 10 kΩ ──●── 10 kΩ ── TP4056 OUT− / system GND
              │            │
              │            └────────── ESP32-C3 GPIO 1 (ADC1)
              └─────────────────────── boost IN+
```

1. If the module has protected `OUT+` / `OUT−`, connect the cell to `B+` / `B−` and the load **and divider** to the switched protected output as above. If your TP4056 board has no protected output, use a properly protected cell or a correctly rated single-cell protection board and take the switched voltage **after** the protection circuit. Do not bypass protection; do not use TP4056 USB `IN+` or the boost's 5 V output as the battery sense point.
2. With the ESP32 disconnected, check the wiring and polarity with a multimeter. Switch the battery ON and measure from the divider midpoint to OUT−/system GND: about **2.10 V at a 4.20 V cell** or **1.65 V at a 3.30 V cell**. Never connect the battery directly to GPIO 1 and never apply more than its permitted input voltage. Confirm the boost outputs 5 V separately before connecting it to the ESP32.
3. After connecting and powering the wearable from the battery, open either AURA dashboard, connect via Wi-Fi, then open **Device controls → Enable TP4056 battery estimate** and confirm that the divider is installed and measured. The confirmed setting is saved on the ESP32 and restored on subsequent restarts, so the watch can show the estimate without the phone. If the UI says the setting could not be saved, resolve the fault before assuming it will persist. Alternatively, before upload set `AURA_TP4056_DIVIDER_WIRED_DEFAULT` to `1` **only after the divider is physically installed and verified**; a previously saved dashboard setting takes precedence. Erasing device flash may clear the stored confirmation.
4. **Before removing or changing the divider**, disable the setting in Device controls, confirm it saved, and power everything down. If sensing is disabled or the ADC reading is outside the accepted range, the watch/app show **`--`**. An unwired or floating ADC can also accidentally give a plausible in-range reading, so the display alone cannot prove that the divider or battery is connected. Verify the circuit with a multimeter. `batHw=true` means sensing is enabled and the ADC reading is in range, not that the battery has been independently detected.
5. The dashboard and OLED show estimated `%` and voltage; the existing `≤15%` low-battery alert uses the valid estimate. Example points in the demo curve: 3.30 V ≈ 0%, 3.68 V ≈ 25%, 3.80 V ≈ 50%, 3.95 V ≈ 75%, 4.18 V ≈ 100%. Real cell chemistry, load sag, temperature and ESP32 ADC calibration can make this inaccurate. Check voltage against a meter; a fuel-gauge IC is needed for a more reliable state-of-charge estimate.

**While charging:** with this safe, simple wiring the slide switch must be **OFF** while the TP4056 charges, so the wearable is off and no live battery percentage is shown during charging. Use the TP4056's LEDs for charge status, according to your board's labels. Showing percentage while charging requires a separately engineered safe load-sharing / power-path design; do not leave the load connected to a basic TP4056 just to display it.

## 5. Coin motor and buzzer wiring

```text
 + motor supply* ──┬──── (+) MOTOR (−) ────┬──── MOSFET drain
                   │                       │
                   └──── K [ DIODE ] A ────┘
                      cathode        anode       MOSFET source ── GND
                      (striped end)
 GPIO 5 ── 100–220 Ω ── MOSFET gate
                           │
                         100 kΩ
                           │
                          GND
```

\* Use a supply appropriate for the motor's **actual** voltage and stall current. If the motor is rated for 3.3 V and the ESP32 regulator can supply the peak current plus the Wi-Fi and sensors, 3V3 may work; otherwise use a suitable separate regulated supply and common GND. A nominal 3 V coin motor is not automatically safe at a fully charged LiPo's 4.2 V or at the boost's 5 V. Check the motor data sheet. Select a logic-level MOSFET that fully turns on at 3.3 V. Observe the diode polarity: cathode to motor positive, anode to the MOSFET drain.

For the mini buzzer, first identify **active** (DC on/off) versus **passive** (tone-driven) and its current/voltage rating. In Device controls select Active DC or Passive tone. Test GPIO 10 only with a properly rated buzzer/module/driver; avoid driving inductive loads directly. The optional active-low toggle is for compatible driver modules. `Test motor` and `Test buzzer` send short commands; they do not verify physical wiring.

## 6. Sensor and OLED notes

- **OLED:** top 16 rows are physically yellow, remaining 48 are blue; the pixels themselves are fixed-color and cannot be made orange through CSS or firmware. The firmware displays seven screens: Home/Score, Heart, SpO₂, Thermal, UV/SPF, TP4056 Battery/Link and Edge Alerts. The web watch mirrors this layout; the surrounding app is orange and black.
- **MAX30102:** place a finger gently over the sensor and hold still. Contact detection and pulse estimation need time; no contact, inadequate signal, or missing module produces `--` and a **NO DATA** score, not fabricated vitals. A finger test is easier than a wrist mount. The experimental SpO₂ calculation has not been clinically validated.
- **DS18B20:** default is its real sensor temperature; there is no automatic "skin-to-core" conversion. If the probe is absent or invalid the score is unavailable. Hot-plugging is not guaranteed; reconnect and reboot.
- **ACEBOTT UV:** the linked product page itself says approximately **0–1100 mV** in its description but elsewhere says **0–5 V**. Those claims conflict. Power from 3V3, verify the actual output with a multimeter in darkness and sunlight **before** connecting to GPIO 0, and keep the input within the ESP32-C3's limits (for calibrated readings, stay within its usable ADC range, approximately 0–2.5 V at 11 dB). If the output can exceed that range, use a correctly sized divider and account for its ratio in the `UV gain` setting. Firmware uses `UV ≈ measured mV / 100 × gain`, capped at 12, as a **provisional** demo mapping; calibrate against an appropriate reference. The limited 200–370 nm spectral response and uncertain calibration do not constitute a certified erythemally weighted UV index. Zero volts cannot distinguish darkness from a disconnected wire.
- **SPF/skin settings:** standard profile warns at UV 6, urgent at UV 8, with a 120-minute demo reminder; sensitive warns at UV 3, urgent at UV 5, with a 60-minute demo reminder. On device startup, sunscreen is **not assumed to have been applied**: log it using the app or a long hold before the countdown starts. At UV 3 or above, an unlogged application produces a reminder. These values are illustrative, not a medically personalized schedule. The demo "exposure budget" is not a safe exposure limit. Cumulative time counts when estimated UV is at least 1; UV-index-minutes are an experimental index × time measure, not a physical UV dose.

## 7. Upload with Arduino IDE 2.x

1. Install **Arduino IDE 2.x**, then install the Espressif **esp32** board package using its official Boards Manager URL: `https://espressif.github.io/arduino-esp32/package_esp32_index.json`.
2. In Library Manager install **Adafruit SSD1306**, **Adafruit GFX Library**, **SparkFun MAX3010x Pulse and Proximity Sensor Library** (`MAX30105.h` and `heartRate.h`), **OneWire** by Paul Stoffregen, and **DallasTemperature** by Miles Burton. Install dependencies when prompted.
3. Open `project_aura_esp32c3/project_aura_esp32c3.ino`.
4. Select **ESP32C3 Dev Module** and set **USB CDC On Boot → Enabled**. Select the correct serial port. If upload fails, use the board's BOOT/reset procedure; some clones require holding BOOT during the start of upload.
5. With battery switch OFF and charger USB unplugged, connect the ESP32 USB-C **data cable**. Upload. Close Arduino Serial Monitor before trying Web Serial; only one program can own the port. `Preferences.h` is included with the ESP32 board package; it is not a separately installed library.
6. Serial is **115200 baud**, one JSON telemetry line approximately every **200 ms**. Raw diagnostic text during reboot can be ignored. After flashing, reboot/reconnect if the USB port changes.

The board starts a local Wi-Fi access point: **`Project-AURA`**, password **`12345678`**, device address **`http://192.168.4.1`**. These are demo credentials. The HTTP API has no authentication or encryption; use only in a trusted demo environment and change the credentials in the sketch before broader use. The confirmed TP4056 divider setting is retained in ESP32 nonvolatile storage; other settings, counters, and alert history are in RAM and reset on reboot.

## 8. Run the demos and connect the device

### Simulation only

Open either HTML file. Select a scenario, adjust sliders, or choose **Run demo**. On the virtual touch pad: **single tap** cycles the seven screens (or acknowledges an active alert); **double tap** changes sensitivity; **hold for at least one second** logs sunscreen. Shortcut buttons provide the same actions. The App Sync toggle freezes only the simulated mobile snapshot while the watch simulation continues.

### Wi-Fi, recommended local bridge

1. Run the firmware and connect your computer to the **Project-AURA** Wi-Fi hotspot. Internet may be unavailable on that connection.
2. Keep `aura_bridge.py` and both named AURA HTML files in the same folder. On that same computer run:

   ```bash
   python3 aura_bridge.py
   ```

3. Open `http://localhost:8765/?bridge=1` for Companion or `http://localhost:8765/studio?bridge=1` for Studio. Click **Connect Wi-Fi**. The local bridge checkbox is preselected and browser requests use the same origin; the Python process forwards only `/status` and `/cmd` to `192.168.4.1`.
4. To stop, press Ctrl+C in the terminal. The helper binds **only to the computer's loopback interface**; it does not make a phone-accessible server. If the device IP is different, start it with `python3 aura_bridge.py --device http://DEVICE_IP`.

**Direct Wi-Fi:** after joining the hotspot, the HTML also has a direct `http://192.168.4.1` option. Browser mixed-content, local-network and file-origin rules vary, so direct access may be blocked; the local bridge is generally more reliable on a computer. Opening the HTML in this chat's sandboxed file preview is fine for simulation, but the preview does not grant network or USB hardware access. Download/open outside the preview for a physical connection.

### USB Web Serial

With the slide switch **OFF** and TP4056 charger cable unplugged, connect the ESP32 USB-C data cable and close the IDE's serial monitor. Open the downloaded HTML in a desktop Chrome/Edge context supporting Web Serial (typically `http://localhost` via the helper or a suitable secure context), click **USB serial**, choose the ESP32 port, and approve permission. Web Serial support/permissions vary by browser and are not available in the sandboxed preview. The helper is not required for serial but is convenient for serving the page locally. USB serial is generally unavailable on iOS browsers.

### Physical test scenarios

In Device controls, select **Send test scenarios to watch** and explicitly confirm. This sets `simOverride=1` and replaces **heart rate, SpO₂, temperature, UV and battery** on the physical watch with simulated values; the UI prominently labels the override. Presets then send demo values to the real OLED and can activate its motor/buzzer. The physical OLED header displays **`[TEST]`** while this override is active, even if the browser closes. Turn the option **OFF** before disconnecting to return to hardware readings; missing sensors return to `--` and need time to acquire. Leaving test mode clears the simulated sunscreen log: log any real application again. Real exposure counters are paused while test values are active. The Disconnect button attempts to disable test mode if the connection is still working, but a dropped link cannot guarantee that command arrived; verify the watch or reboot it. The battery value in test mode is synthetic even if a divider is installed. Never interpret a test override as a live measurement.

A real disconnection does not upload historical events that occurred while the browser was absent. The MCU continues evaluating its rules and driving its local alerts, but persistent logging / true background phone push would require additional firmware storage and a separate app or service.

## 9. Telemetry, commands and scoring

The ESP32 serves `GET /status` and `GET /cmd?key=value&...`; serial accepts `CMD:key=value&...\n`. Both HTML variants use the same protocol.

Telemetry includes `fw`, `mcu`, `hr`, `spo2`, `temp`, `tempRaw`, `uv`, `uvFloat`, `uvMv`, `bat`, `batV`, `batHw`, `batSense`, `batSenseSaveOk`, `score`, `band`, `heatPred`, `hrValid`, `spo2Valid`, `tempValid`, `tempOffsetOn`, `uvGain`, `maxOk`, `finger`, `dsOk`, `oledOk`, `touch`, `gesture`, `sens`, `sensSeq`, `standalone`, `th`, `sun`, `spfLogged`, `exposureMin`, `uvDose`, `sunSeq`, `snd`, `vib`, `buzMode`, `invBuz`, `invTouch`, `buzOn`, `vibOn`, `simOverride`, `scr`, `scrSeq`, `ackSeq`, `alertActive`, `alertLatched` and `raw`. Unavailable vitals, battery and score are JSON `null`. `batHw` means an enabled, plausible divider measurement, **not** a guarantee of wiring or accuracy. `batSenseSaveOk=false` indicates that the last attempt to persist the sensing setting failed. The analog UV wire cannot be checked for disconnection automatically.

Commands include `scr`, `ack`, `sens`, `snd`, `vib`, `buzMode`, `invBuz`, `invTouch`, `testBuz`, `testVib`, `sunReset`, `sun`, `expReset`, `batSense`, `bat`, `uvGain`, `standalone`, `simOverride`, `simHr`, `simSpo2`, `simTemp`, `simUv`, `hl`, `hh`, `sp`, and `tp`. `bat` supplies only the simulated battery when test override is on. There are also `useOffset`/`rezero` demonstration commands; a fixed offset **does not** turn a skin probe into a core-temperature sensor, so they are disabled by default and not presented as health calibration.

**Composite score (illustrative):** start at 100, subtract weighted penalties for UV, an unlogged or elapsed SPF reminder at UV 3+, HR, SpO₂ and temperature; add a 12-point penalty for a compound UV + thermal/HR pattern. Clamp to 0–100; ≥80 = `OPTIMAL`, 55–79 = `CAUTION`, <55 = `HIGH RISK`. The same formula is used by the JavaScript simulator and sketch; when connected, the device's reported score is authoritative for the twin. If vital data is missing, the score is `NO DATA` rather than nominal. The score is not clinically validated, and the UV sensor can still be disconnected without detection.

For transparency, the demo formula is:

```text
effectiveUV = sensitive ? uvFloat × 1.35 : uvFloat
penalty = effectiveUV > 2 ? min(38, (effectiveUV − 2) × 4) : 0
if UV ≥ 3 and SPF is unlogged or due: penalty += 8

if HR > high:     penalty += 18 + min(14, (HR − high) × 0.45)
else if HR < low: penalty += 18 + min(14, (low − HR) × 0.65)
else if HR > high − 14: penalty += (HR − (high − 14)) × 0.4

if SpO₂ < threshold: penalty += 22 + min(16, (threshold − SpO₂) × 3)
else if SpO₂ < 96:  penalty += (96 − SpO₂) × 2

if temp > threshold: penalty += 18 + min(14, (temp − threshold) × 10)
else if temp > 37.3: penalty += (temp − 37.3) × 9

heatUV = UV ≥ (sensitive ? 4 : 6) and
         (temp ≥ 37.4 °C or HR ≥ high − 12)
if heatUV: penalty += 12
score = clamp(round(100 − penalty), 0, 100)
```

The threshold comparison uses the integer UV index; the UV penalty uses the one-decimal `uvFloat`. Temperature is the sensor reading, not inferred core temperature. Both implementations use 32-bit-float-equivalent intermediate arithmetic for consistent rounding.

## 10. Troubleshooting

| Symptom | Check |
|---|---|
| OLED blank | Confirm 4-pin I²C SSD1306, correct VCC/GND pin order and 3V3, GPIO 6/7, common ground and address 0x3C/0x3D. Reboot. |
| MAX not found / no pulse | Verify module regulator and I²C pull-ups, shared GND, 0x57, contact and LED window; hold a finger still for several seconds. Wrist optics need careful mechanical design. |
| DS18B20 unavailable | Verify DATA on GPIO 3, 3V3 and GND, pull-up wiring, probe pinout and powered mode. Try 4.7 kΩ if 10 kΩ is marginal; reboot. |
| Battery `--` | Install and verify the two-resistor divider from switched **protected TP4056 OUT+** to system GND, enable the TP4056 estimate in Device controls, turn the battery switch ON, and confirm midpoint voltage. It is expected to be unavailable when only USB powers the board with the battery switch OFF. The TP4056 LEDs alone cannot generate a percentage. |
| Motor/buzzer silent | Check transistor/diode polarity, supply rating, common GND, GPIO 5/10, device vibration/sound setting, and buzzer mode; use the test buttons. Never test by shorting a motor directly across a GPIO. |
| Wi-Fi/USB doesn't link | Join the correct hotspot; upload the correct sketch; try the local helper; check browser permissions and network restrictions. Close the serial monitor and enable USB CDC on Boot for USB. The in-chat preview cannot access the device. |
| Physical screen shows unexpected sample values | Check the large TEST VALUES warning. Disable physical test override and wait for real sensors to reacquire. |
| SuperMini resets with Wi-Fi/motor | Check 5 V output under load, battery state, wiring, motor supply/driver, and regulator current capacity. Do not assume the boost's advertised maximum current is guaranteed. |

### Product references

- [Yellow + blue 0.96-inch OLED](https://makerbazar.in/products/0-96-inch-128x64-oled-display-module?variant=47397087871216)
- [MAX30102 black module](https://makerbazar.in/products/max30102-heart-rate-and-pulse-oximeter-sensor-module-black)
- [Red 1-channel TTP223R module](https://makerbazar.in/products/capacitive-touch-sensor-switch-module?variant=48251073593584)
- [Selectable mini boost module](https://makerbazar.in/products/3-7v-to-12v-mini-dc-dc-boost-step-up-converter-board-module-5v-8v-9v-12v-output-1); [similar A/B pad table](https://makerselectronics.com/product/mini-dc-dc-boost-step-up-converter-3-7v-to-5v-8v-9v-12v/)
- [ACEBOTT UV module](https://robu.in/product/acebott-uv-sensor/) and [manufacturer QB104 guide](https://acebott.com/docs/qb104-uv-sensor/)
- [TP4056 datasheet: charging and CHRG/STDBY status outputs](https://www.evvosemi.com/Uploads/file/20251222/2025122211002912.pdf)
