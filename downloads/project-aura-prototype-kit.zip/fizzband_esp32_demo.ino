/*
 * ======================================================================================
 *  PROJECT AURA (Advanced UV & Risk-prediction Assistant) — Wearable Edge Firmware v2.1
 *  Target MCU: ESP32-C3 SuperMini (RISC-V @ 160 MHz, Wi-Fi + Native USB-C CDC)
 * ======================================================================================
 *
 *  ACTUAL WEARABLE HARDWARE BOM & PIN MAPPING (ESP32-C3 SuperMini):
 *  -------------------------------------------------------------------------------------
 *  1. 0.96" OLED (Yellow+Blue) : VCC -> 3V3 | GND -> GND | SDA -> GPIO 6 | SCL -> GPIO 7
 *                                (128x64 SSD1306 I2C: y=0..15 Yellow bar, y=16..63 Blue)
 *  2. MAX30102 Pulse Oximeter  : VIN -> 3V3 | GND -> GND | SDA -> GPIO 6 | SCL -> GPIO 7
 *                                (Black PCB module shares 400kHz I2C bus @ 0x57)
 *  3. ACEBOTT UV Sensor (QB104): VCC -> 3V3 | GND -> GND | SIG (S) -> GPIO 0 (ADC1_CH0)
 *                                (Linear 0-1100 mV analog output -> UV Index 0.0-11.0+)
 *  4. TP4056 BATTERY SENSE (two EXTRA 10k resistors required):
 *     TP4056 protected OUT+ -> slide switch ->[10k]--+--[10k]--> OUT- / GND
 *                                                   +--> GPIO 1 (ADC1)
 *     This reads the cell voltage before the boost converter. TP4056 CHRG/STDBY only
 *     indicate charger status; they do not provide a percentage. AURA converts the
 *     ADC voltage into an APPROXIMATE percentage. Enable sensing ONLY after wiring
 *     and measuring the divider. Without it the battery reading is unavailable.
 *  5. DS18B20 Temp Probe       : VDD -> 3V3 | GND -> GND | DATA -> GPIO 3
 *                                (Connect your 10k resistor between GPIO 3 and 3V3!)
 *  6. TTP223R Touch (Red)      : VCC -> 3V3 | GND -> GND | I/O (SIG) -> GPIO 4
 *                                (Active-HIGH touch: Tap = Next/ACK, Double-Tap = Skin
 *                                 Sensitivity Mode, Long-Hold = Log Sunscreen SPF!)
 *  7. Coin Vibration Motor     : GPIO 5 -> transistor DRIVER; motor + -> rated supply;
 *                                motor - -> transistor; flyback diode across motor REQUIRED.
 *  8. Mini Buzzer              : GPIO 10 -> suitable driver/module; do not exceed GPIO rating.
 *  9. Built-in Status LED      : GPIO 8 (ESP32-C3 SuperMini onboard Blue LED, Active-LOW)
 * 10. Backup Physical Button   : GPIO 9 (ESP32-C3 SuperMini onboard BOOT button)
 *
 *  POWER CHAIN SAFETY NOTE:
 *  3.7V LiPo (523450) -> TP4056 Type-C (B+/B-) -> TP4056 OUT+ -> 3-Pin Slide Switch ->
 *  Mini DC-DC Boost VIN+ -> Boost VOUT+ -> ESP32-C3 5V pin.
 *  Some A/B-selectable boost boards default to 12V; A=0,B=0 commonly selects 5V.
 *  VERIFY YOUR BOARD and measure 5.0V at the output before connecting the ESP32.
 *  Turn Slide Switch OFF before plugging USB-C into ESP32-C3 for flashing/Web Serial.
 *  Turn the load OFF while charging via TP4056; see hardware guide for LiPo protection,
 *  charge current, backfeed, and voltage validation. Never connect a motor directly to GPIO.
 *
 *  PROTOTYPE ONLY: Outputs and score are experimental, not clinical or UV protection
 *  advice. Invalid MAX30102 contact, DS18B20 or battery sense is flagged as unavailable.
 *  The analog UV input cannot detect a disconnected sensor. Calibrate against a reference.
 *
 *  ARDUINO IDE 2.x SETTINGS (CRITICAL FOR ESP32-C3 SUPERMINI):
 *  - Board            : "ESP32C3 Dev Module"
 *  - USB CDC On Boot  : "Enabled"   <-- Required for USB Web Serial Bridge!
 *
 *  REQUIRED ARDUINO LIBRARIES (Sketch -> Include Library -> Manage Libraries):
 *  1. Adafruit SSD1306                        (by Adafruit)
 *  2. Adafruit GFX Library                    (by Adafruit)
 *  3. SparkFun MAX3010x Pulse and Proximity   (by SparkFun Electronics -> MAX30105.h)
 *  4. OneWire                                 (by Paul Stoffregen)
 *  5. DallasTemperature                       (by Miles Burton)
 * ======================================================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MAX30105.h>
#include <heartRate.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Preferences.h> // Bundled with the ESP32 Arduino core; stores confirmed battery wiring setting.
#include <math.h>

// ---------------- ESP32-C3 SUPERMINI PIN DEFINITIONS ----------------
#define PIN_UV_ADC      0   // ADC1_CH0: ACEBOTT UV Sensor analog output (0-1100 mV)
#define PIN_BAT_ADC     1   // ADC1_CH1: switched TP4056 OUT+ via 2x10k divider (1.5-2.1V)
#define PIN_DS18B20     3   // OneWire DATA (+ 10k pull-up resistor to 3V3)
#define PIN_TOUCH       4   // TTP223R Red Capacitive Touch SIG (Active-HIGH default)
#define PIN_VIB_MOTOR   5   // Coin Vibration Motor haptic output
#define PIN_I2C_SDA     6   // Shared Fast I2C SDA (0.96" SSD1306 OLED + MAX30102)
#define PIN_I2C_SCL     7   // Shared Fast I2C SCL (0.96" SSD1306 OLED + MAX30102)
#define PIN_STATUS_LED  8   // ESP32-C3 SuperMini onboard Blue LED (Active-LOW)
#define PIN_BOOT_BTN    9   // ESP32-C3 SuperMini onboard BOOT button (Active-LOW backup)
#define PIN_BUZZER     10   // Mini Buzzer output (Active DC or Passive PWM Tone)

// Set to 1 ONLY after wiring and verifying the switched TP4056 output divider.
// Stored confirmation from the dashboard overrides this default on later boots.
#define AURA_TP4056_DIVIDER_WIRED_DEFAULT 0

// ---------------- WI-FI SOFTAP SETTINGS ----------------
const char* AP_SSID = "Project-AURA";
const char* AP_PASS = "12345678";   // Connect laptop/phone -> http://192.168.4.1

// ---------------- 0.96" YELLOW+BLUE SSD1306 OLED ----------------
// Top 16 rows (y = 0..15) = YELLOW zone | Bottom 48 rows (y = 16..63) = BLUE zone
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT   64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
bool oledOk = false;
uint8_t oledAddr = 0x3C;

// ---------------- SENSORS & SERVER OBJECTS ----------------
MAX30105 particleSensor;
bool maxOk = false;

OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
bool dsSensorFound = false;

WebServer server(80);

// ---------------- LIVE TELEMETRY & EDGE STATE ----------------
int   hrBpm        = 78;     // Live Heart Rate (BPM)
int   spo2Pct      = 98;     // Live Blood Oxygen (%)
float tempC        = 36.8f;  // Calibrated Body/Skin Temperature (C)
float rawTempC     = 28.0f;  // Raw DS18B20 reading (C)
float uvIndexFloat = 1.8f;   // Precise UV Index (0.0 - 12.0)
int   uvIndex      = 2;      // Rounded UV Index (0 - 12)
int   uvMilliVolts = 180;    // ACEBOTT UV raw calibrated mV

// Battery Percentage State (3.7V 523450 LiPo)
int   batPct       = 0;
float batVolts     = 0.0f;
bool  batterySenseEnabled = AURA_TP4056_DIVIDER_WIRED_DEFAULT != 0; // Confirmed wired only
bool  batterySenseSaveOk = true;    // Last attempt to save wiring configuration succeeded
bool  batHwDetected = false;       // Enabled + plausible ADC; cannot detect every disconnected wire
bool  batValid = false;            // False until enabled+valid or demo override is active
int   simBat = 85;                 // Synthetic; used ONLY while simOverride=true
float batVoltageEma = 0.0f;
const float BAT_DIVIDER_RATIO = 2.0f; // 10k + 10k divider -> Vbat = Vadc * 2.0

// MAX30102 Non-Blocking PPG & R-Ratio SpO2 State
bool     fingerDetected = false;
bool     hrValid = false, spo2Valid = false, tempValid = false;
unsigned long lastHrGoodMs = 0, lastSpo2GoodMs = 0, lastPpgSampleMs = 0;
uint8_t  validBeatCount = 0;
uint32_t latestIr       = 0;
uint32_t latestRed      = 0;
unsigned long lastBeatMs = 0;
uint8_t  beatHist[6]    = {0, 0, 0, 0, 0, 0};
uint8_t  beatIdx        = 0;
float    bpmEma         = 78.0f;
float    spo2Ema        = 98.0f;

// Rolling 100-sample AC/DC accumulator for non-blocking SpO2 (~1 sec @ 100 sps)
uint16_t ppgWinCount = 0;
double   irSum = 0, redSum = 0;
uint32_t irMin = 0xFFFFFFFF, irMax = 0;
uint32_t redMin = 0xFFFFFFFF, redMax = 0;

// Optional Demo Vital Override (lets Web App test Hypoxia/Tachycardia on real Watch!)
bool  simOverride = false;
int   simHr       = 78;
int   simSpo2     = 98;
float simTemp     = 36.8f;
int   simUv       = -1;      // -1 = use live ACEBOTT UV sensor

// Calibration & Personalization Settings (Two-Way Synced with Web App)
bool  sensitiveSkin = false; // Personalized Skin Sensitivity Mode (Normal vs Sensitive)
bool  useBodyOffset = false; // DEMO ONLY. A fixed offset is NOT core temperature.
float tempOffset    = 0.0f;
float uvGain        = 1.0f;  // 1.0x sunlight, or >1.0x indoor demo boost
int   sunElapsedMin = 0;     // Real elapsed minutes since last logged application
bool  spfLogged = false;     // Do not assume sunscreen was applied at startup.
float exposureMinutes = 0.0f; // Approx. time with UV index >= 1 (not a clinical dose)
float uvIndexMinutes = 0.0f;  // Integral of estimated UV index over minutes
bool  standaloneSim = false; // Mirrors BLE link pause for demoing Edge Autonomy

// Safety Thresholds (Editable from Mobile/Web App, Evaluated Locally on Edge!)
int   thHrLow  = 50;
int   thHrHigh = 120;
int   thSpo2   = 92;
float thTemp   = 38.0f;

// Composite Safety Scoring & Edge Alert Engine
int   auraScore     = 94;    // 0 - 100 Composite Safety Score
const char* auraBand = "NO DATA";
bool  scoreValid = false;
bool  heatStrainPred = false; // Synergistic Heat + UV Risk Prediction flag
bool  alertActive    = false;
bool  alertUrgent    = false;
bool  alertLatched   = false;
uint8_t activeAlertCount = 0;
String topAlertTitle = "ALL SAFE";
String topAlertDetail = "Vitals & UV nominal";
uint16_t prevRuleMask = 0;

// OLED Watch Navigation (7 Screens: 0..6)
// 0: Home + AURA Score | 1: Heart (MAX30102) | 2: SpO2 (MAX30102) | 3: Temp (DS18B20)
// 4: UV + Sunscreen    | 5: Battery & Power  | 6: Edge Alerts
int  watchScreen = 0;
const int NUM_SCREENS = 7;

// Event Sequence Counters for Instant Two-Way Web Sync
unsigned long scrSeq  = 0;
unsigned long ackSeq  = 0;
unsigned long sunSeq  = 0;
unsigned long sensSeq = 0;
String lastTouchGesture = "none";

// TTP223R Capacitive Touch + BOOT Button Gesture State Machine
bool invTouch         = false; // False = Active-HIGH (TTP223 default A=0,B=0)
bool touchNow         = false;
bool touchRawPrev     = false;
bool touchStable      = false;
unsigned long touchDebounceMs = 0;
unsigned long touchDownMs     = 0;
bool touchLongHandled = false;
uint8_t tapPendingCount = 0;
unsigned long lastTapReleaseMs = 0;

// Non-Blocking Coin Vibration Motor (GPIO 5) & Mini Buzzer (GPIO 10) Sequencers
bool vibEnabled  = true;
bool buzEnabled  = true;
int  buzMode     = 1;     // 0 = Active DC buzzer, 1 = Passive PWM tone() mini buzzer
bool invBuz      = false; // True if active-LOW transistor driver

bool vibCurrentlyOn = false;
unsigned long vibOffAtMs = 0;
uint8_t vibPulsesLeft = 0;
unsigned long vibNextPulseMs = 0;

bool buzCurrentlyOn = false;
unsigned long buzOffAtMs = 0;
unsigned long lastAlarmCycleMs = 0;

// Loop Timing
unsigned long lastSensorMs = 0;
unsigned long lastTempMs   = 0;
unsigned long lastOledMs   = 0;
unsigned long lastSerialMs = 0;
unsigned long lastMinuteMs = 0;
unsigned long lastExposureMs = 0;

// ======================================================================================
//  ACTUATOR DRIVERS: COIN VIBRATION MOTOR (GPIO 5) & MINI BUZZER (GPIO 10)
// ======================================================================================
void setVibMotorRaw(bool on) {
  vibCurrentlyOn = on;
  digitalWrite(PIN_VIB_MOTOR, on ? HIGH : LOW);
}

void triggerHapticPulses(uint8_t count, uint16_t onMs) {
  if (!vibEnabled || count == 0) return;
  setVibMotorRaw(true);
  vibOffAtMs = millis() + onMs;
  vibPulsesLeft = count - 1;
}

void setBuzzerRaw(bool on, uint16_t freqHz = 2400) {
  buzCurrentlyOn = on;
  if (buzMode == 1) {
    if (on) tone(PIN_BUZZER, freqHz);
    else noTone(PIN_BUZZER);
  } else {
    bool level = invBuz ? !on : on;
    digitalWrite(PIN_BUZZER, level ? HIGH : LOW);
  }
}

void triggerAudioPip(uint16_t durationMs, uint16_t freqHz = 2200) {
  if (!buzEnabled) return;
  setBuzzerRaw(true, freqHz);
  buzOffAtMs = millis() + durationMs;
}

void serviceActuators() {
  unsigned long now = millis();

  // Finish single/multi haptic pulse
  if (vibCurrentlyOn && vibOffAtMs > 0 && now >= vibOffAtMs) {
    setVibMotorRaw(false);
    vibOffAtMs = 0;
    if (vibPulsesLeft > 0) {
      vibNextPulseMs = now + 70;
    }
  }
  if (!vibCurrentlyOn && vibPulsesLeft > 0 && now >= vibNextPulseMs) {
    vibPulsesLeft--;
    setVibMotorRaw(true);
    vibOffAtMs = now + 55;
  }

  // Finish one-shot buzzer pip
  if (buzCurrentlyOn && buzOffAtMs > 0 && now >= buzOffAtMs) {
    setBuzzerRaw(false);
    buzOffAtMs = 0;
  }

  // Periodic repeating alarm pattern while an unacknowledged Edge Alert is active
  if (alertLatched && alertActive) {
    unsigned long period = alertUrgent ? 1400 : 2800;
    if (now - lastAlarmCycleMs >= period) {
      lastAlarmCycleMs = now;
      if (vibEnabled) triggerHapticPulses(alertUrgent ? 2 : 1, alertUrgent ? 140 : 90);
      if (buzEnabled) triggerAudioPip(alertUrgent ? 180 : 100, alertUrgent ? 2700 : 1850);
    }
    // Flash ESP32-C3 onboard Blue LED (GPIO 8, Active-LOW)
    bool ledOn = ((now / 220) % 2) == 0;
    digitalWrite(PIN_STATUS_LED, ledOn ? LOW : HIGH);
  } else {
    digitalWrite(PIN_STATUS_LED, HIGH); // LED OFF (Active-LOW)
  }
}

// ======================================================================================
//  TP4056 / SINGLE-CELL BATTERY SENSE CONFIGURATION AND ESTIMATE
// ======================================================================================
// A floating ADC can give a plausible reading, so do not auto-detect a divider.
// Explicit confirmation is stored in ESP32 NVS; disable it BEFORE removing the divider.
void restoreBatterySenseSetting() {
  Preferences prefs;
  if (prefs.begin("aura-power", true)) {
    batterySenseEnabled = prefs.getBool("tp_sense", AURA_TP4056_DIVIDER_WIRED_DEFAULT != 0);
    prefs.end();
  }
}

bool saveBatterySenseSetting(bool enabled) {
  Preferences prefs;
  if (!prefs.begin("aura-power", false)) return false;
  size_t written = prefs.putBool("tp_sense", enabled);
  prefs.end();
  return written == 1;
}

// Voltage curve is a rough demo estimate, not a fuel gauge or charge-state indicator.
// ======================================================================================
int lipoVoltsToPercent(float v) {
  if (v >= 4.18f) return 100;
  if (v <= 3.30f) return 0;
  // Piecewise LiPo discharge curve (4.20V -> 3.30V)
  if (v >= 3.95f) return 75 + (int)((v - 3.95f) / (4.18f - 3.95f) * 25.0f);
  if (v >= 3.80f) return 50 + (int)((v - 3.80f) / (3.95f - 3.80f) * 25.0f);
  if (v >= 3.68f) return 25 + (int)((v - 3.68f) / (3.80f - 3.68f) * 25.0f);
  if (v >= 3.50f) return 8  + (int)((v - 3.50f) / (3.68f - 3.50f) * 17.0f);
  return (int)((v - 3.30f) / (3.50f - 3.30f) * 8.0f);
}

float percentToLipoVolts(int pct) {
  return 3.30f + (constrain(pct, 0, 100) / 100.0f) * 0.90f;
}

// ======================================================================================
//  ACEBOTT UV SENSOR (QB104) MILLIVOLT -> UV INDEX CONVERTER
// ======================================================================================
float mvToUvIndex(int mv) {
  // Provisional DEMO mapping based on the listing's 0–1100 mV claim.
  // The manufacturer also gives conflicting 0–5V guidance; verify output voltage and
  // calibrate vs a reference. Spectral response is not a certified UV-index instrument.
  return constrain(mv / 100.0f, 0.0f, 12.0f);
}

// ======================================================================================
//  NON-BLOCKING MAX30102 HEART RATE & SpO2 ENGINE
// ======================================================================================
void pollMax30102() {
  if (!maxOk) return;
  particleSensor.check();

  uint8_t drained = 0;
  while (particleSensor.available() && drained < 10) {
    drained++;
    uint32_t red = particleSensor.getFIFORed();
    uint32_t ir  = particleSensor.getFIFOIR();
    particleSensor.nextSample();

    latestIr  = ir;
    latestRed = red;
    lastPpgSampleMs = millis();

    if (ir < 45000) {
      // Never present stale or initial demo vitals as real readings.
      fingerDetected = false;
      hrValid = spo2Valid = false;
      lastBeatMs = lastHrGoodMs = lastSpo2GoodMs = 0;
      validBeatCount = beatIdx = 0;
      ppgWinCount = 0;
      irSum = 0; redSum = 0;
      irMin = 0xFFFFFFFF; irMax = 0;
      redMin = 0xFFFFFFFF; redMax = 0;
      continue;
    }

    fingerDetected = true;

    // 1. Beat detection for live BPM
    if (checkForBeat(ir)) {
      unsigned long now = millis();
      unsigned long delta = lastBeatMs ? now - lastBeatMs : 0;
      lastBeatMs = now;
      if (delta >= 300 && delta <= 1500) { // 40–200 BPM
        float instantBpm = 60000.0f / (float)delta;
        beatHist[beatIdx] = (uint8_t)constrain((int)roundf(instantBpm), 42, 195);
        beatIdx = (beatIdx + 1) % 6;
        if (validBeatCount < 6) validBeatCount++;
        int sum = 0;
        for (int i = 0; i < validBeatCount; i++) sum += beatHist[i];
        float avgBpm = sum / (float)validBeatCount;
        bpmEma = (validBeatCount == 1) ? avgBpm : 0.70f * bpmEma + 0.30f * avgBpm;
        lastHrGoodMs = now;
        hrValid = validBeatCount >= 2; // Need multiple beats, not a fabricated baseline.
        if (!simOverride) hrBpm = constrain((int)roundf(bpmEma), 40, 195);
      }
    }

    // 2. Rolling 100-sample AC/DC Ratio-of-Ratios for SpO2
    irSum += ir;
    redSum += red;
    if (ir < irMin) irMin = ir;
    if (ir > irMax) irMax = ir;
    if (red < redMin) redMin = red;
    if (red > redMax) redMax = red;
    ppgWinCount++;

    if (ppgWinCount >= 100) {
      double irDc  = irSum / 100.0;
      double redDc = redSum / 100.0;
      double irAc  = (double)(irMax - irMin);
      double redAc = (double)(redMax - redMin);

      if (irDc > 1000.0 && redDc > 1000.0 && irAc > 60.0 && irAc < 15000.0) {
        double rRatio = (redAc / redDc) / (irAc / irDc);
        double calcSpo2 = 104.0 - 17.0 * rRatio;
        calcSpo2 = constrain(calcSpo2, 86.0, 100.0);
        spo2Ema = spo2Valid ? (0.80f * spo2Ema + 0.20f * (float)calcSpo2) : (float)calcSpo2;
        spo2Valid = true;
        lastSpo2GoodMs = millis();
        if (!simOverride) {
          spo2Pct = constrain((int)roundf(spo2Ema), 85, 100);
        }
      }
      ppgWinCount = 0;
      irSum = 0; redSum = 0;
      irMin = 0xFFFFFFFF; irMax = 0;
      redMin = 0xFFFFFFFF; redMax = 0;
    }
  }
  if (fingerDetected && millis() - lastPpgSampleMs > 1500) fingerDetected = false;
  if (hrValid && millis() - lastHrGoodMs > 5000) hrValid = false;
  if (spo2Valid && millis() - lastSpo2GoodMs > 5000) spo2Valid = false;
}

// ======================================================================================
//  POLL ANALOG UV (GPIO 0), BATTERY % (GPIO 1) & DS18B20 TEMP (GPIO 3)
// ======================================================================================
void pollAnalogAndTemp() {
  unsigned long now = millis();

  // Every 80ms: Sample ACEBOTT UV Sensor & LiPo Battery Divider
  if (now - lastSensorMs >= 80) {
    lastSensorMs = now;

    // 1. ACEBOTT UV Sensor on GPIO 0 (8x oversampled factory-calibrated millivolts)
    long mvAcc = 0;
    for (int i = 0; i < 8; i++) mvAcc += analogReadMilliVolts(PIN_UV_ADC);
    int rawUvMv = (int)(mvAcc / 8);
    uvMilliVolts = rawUvMv;

    float scaledMv = rawUvMv * uvGain;
    static float uvFloatEma = -1.0f;
    float targetUv = mvToUvIndex((int)scaledMv);
    if (uvFloatEma < 0) uvFloatEma = targetUv;
    uvFloatEma = 0.78f * uvFloatEma + 0.22f * targetUv;

    if (simOverride && simUv >= 0) {
      uvIndexFloat = (float)simUv;
      uvIndex = constrain(simUv, 0, 12);
    } else {
      uvIndexFloat = roundf(constrain(uvFloatEma, 0.0f, 12.0f) * 10.0f) / 10.0f;
      uvIndex = constrain((int)roundf(uvIndexFloat), 0, 12);
    }

    // GPIO1 FLOATING CANNOT PROVE A DIVIDER IS PRESENT. Only read after explicit opt-in.
    batHwDetected = false;
    batValid = false;
    if (batterySenseEnabled && !simOverride) {
      long batMvAcc = 0;
      for (int i = 0; i < 8; i++) batMvAcc += analogReadMilliVolts(PIN_BAT_ADC);
      int adcBatMv = (int)(batMvAcc / 8);
      if (adcBatMv >= 1200 && adcBatMv <= 2300) {
        batHwDetected = batValid = true;
        float vInstant = (adcBatMv / 1000.0f) * BAT_DIVIDER_RATIO;
        if (batVoltageEma < 2.4f) batVoltageEma = vInstant;
        batVoltageEma = 0.92f * batVoltageEma + 0.08f * vInstant;
        batVolts = batVoltageEma;
        batPct = constrain(lipoVoltsToPercent(batVolts), 0, 100);
      }
    } else if (simOverride) {
      batValid = true;
      batPct = simBat;
      batVolts = percentToLipoVolts(simBat); // Synthetic, clearly marked as DEMO.
    }

    // Apply Web Demo Override if enabled for HR/SpO2/Temp
    if (simOverride) {
      hrBpm   = simHr;
      spo2Pct = simSpo2;
      tempC   = simTemp;
    }
  }

  // Every 800ms: Non-blocking DS18B20 Temperature Probe on GPIO 3
  if (now - lastTempMs >= 800) {
    lastTempMs = now;
    if (dsSensorFound) {
      float t = ds18b20.getTempCByIndex(0);
      if (t > -30.0f && t < 85.0f) {
        rawTempC = t;
        tempValid = true;
        if (!simOverride) {
          tempC = useBodyOffset ? (rawTempC + tempOffset) : rawTempC;
          tempC = roundf(constrain(tempC, -20.0f, 85.0f) * 10.0f) / 10.0f;
        }
      } else {
        tempValid = false;
      }
      ds18b20.requestTemperatures();
    } else {
      tempValid = false;
    }
  }

  // SPF timer is elapsed clock time, not just time spent under a UV lamp.
  if (now - lastMinuteMs >= 60000) {
    lastMinuteMs += 60000;
    if (spfLogged && sunElapsedMin < 240) sunElapsedMin++;
  }
  // Approximate exposure only: zero voltage cannot prove that the UV sensor is connected.
  if (now - lastExposureMs >= 1000) {
    float dtMinutes = (now - lastExposureMs) / 60000.0f;
    lastExposureMs = now;
    if (!simOverride && uvIndexFloat >= 1.0f) { // Do not contaminate real counters with demo UV.
      exposureMinutes += dtMinutes;
      uvIndexMinutes += uvIndexFloat * dtMinutes;
    }
  }
}

bool hasHr() { return simOverride || (maxOk && fingerDetected && hrValid); }
bool hasSpo2() { return simOverride || (maxOk && fingerDetected && spo2Valid); }
bool hasTemp() { return simOverride || (dsSensorFound && tempValid); }

// ======================================================================================
//  PROJECT AURA COMPOSITE SAFETY SCORING & STANDALONE EDGE SAFETY ENGINE
// ======================================================================================
int sunLimitMinutes() {
  return sensitiveSkin ? 60 : 120;
}

void evaluateEdgeSafety() {
  int warnUv = sensitiveSkin ? 3 : 6;
  int urgUv  = sensitiveSkin ? 5 : 8;
  int sLim   = sunLimitMinutes();

  // --- 1. Compute Composite Safety Score (0 - 100) ---
  float penalty = 0.0f;

  // (a) UV Exposure Penalty (Personalized by Skin Sensitivity Mode)
  float effUv = sensitiveSkin ? (uvIndexFloat * 1.35f) : uvIndexFloat;
  if (effUv > 2.0f) {
    penalty += min(38.0f, (effUv - 2.0f) * 4.0f);
  }
  if ((!spfLogged || sunElapsedMin >= sLim) && uvIndex >= 3) {
    penalty += 8.0f;
  }

  // (b) Cardiovascular Strain Penalty (BPM)
  if (hasHr() && hrBpm > thHrHigh) {
    penalty += 18.0f + min(14.0f, (hrBpm - thHrHigh) * 0.45f);
  } else if (hasHr() && hrBpm < thHrLow) {
    penalty += 18.0f + min(14.0f, (thHrLow - hrBpm) * 0.65f);
  } else if (hasHr() && hrBpm > (thHrHigh - 14)) {
    penalty += (hrBpm - (thHrHigh - 14)) * 0.4f;
  }

  // (c) Blood Oxygen Penalty (SpO2)
  if (hasSpo2() && spo2Pct < thSpo2) {
    penalty += 22.0f + min(16.0f, (thSpo2 - spo2Pct) * 3.0f);
  } else if (hasSpo2() && spo2Pct < 96) {
    penalty += (96 - spo2Pct) * 2.0f;
  }

  // (d) Thermal Load Penalty (DS18B20)
  if (hasTemp() && tempC > thTemp) {
    penalty += 18.0f + min(14.0f, (tempC - thTemp) * 10.0f);
  } else if (hasTemp() && tempC > 37.3f) {
    penalty += (tempC - 37.3f) * 9.0f;
  }

  // (e) AURA Synergistic Heat-UV Risk Prediction Cross-Term
  heatStrainPred = (uvIndex >= (sensitiveSkin ? 4 : 6)) &&
                   ((hasTemp() && tempC >= 37.4f) || (hasHr() && hrBpm >= (thHrHigh - 12)));
  if (heatStrainPred) {
    penalty += 12.0f;
  }

  scoreValid = hasHr() && hasSpo2() && hasTemp();
  auraScore = scoreValid ? constrain((int)roundf(100.0f - penalty), 0, 100) : -1;
  auraBand  = !scoreValid ? "NO DATA" : (auraScore >= 80) ? "OPTIMAL" : (auraScore >= 55) ? "CAUTION" : "HIGH RISK";

  // --- 2. Standalone Edge Alert Rule Evaluation ---
  uint16_t mask = 0;
  activeAlertCount = 0;
  alertUrgent = false;
  topAlertTitle = "ALL SAFE";
  topAlertDetail = scoreValid ? ("Score " + String(auraScore) + "/100") : "Check vital sensors";

  auto addAlert = [&](uint8_t bit, bool urgent, const char* title, String detail) {
    mask |= (1 << bit);
    if (activeAlertCount == 0 || (urgent && !alertUrgent)) {
      topAlertTitle = title;
      topAlertDetail = detail;
    }
    if (urgent) alertUrgent = true;
    activeAlertCount++;
  };

  if (uvIndex >= urgUv) {
    addAlert(0, true, uvIndex >= 11 ? "EXTREME UV!" : "HIGH UV RISK",
             "UV " + String(uvIndex) + (sensitiveSkin ? " (Sens)" : "") + " Seek shade");
  }
  if (hasSpo2() && spo2Pct < thSpo2) {
    addAlert(1, true, "LOW SpO2!", "SpO2 " + String(spo2Pct) + "% < " + String(thSpo2) + "%");
  }
  if (hasHr() && hrBpm > thHrHigh) {
    addAlert(2, true, "HIGH PULSE!", String(hrBpm) + " BPM > " + String(thHrHigh));
  } else if (hasHr() && hrBpm < thHrLow) {
    addAlert(3, true, "LOW PULSE!", String(hrBpm) + " BPM < " + String(thHrLow));
  }
  if (hasTemp() && tempC > thTemp) {
    addAlert(4, true, "HIGH TEMP!", String(tempC, 1) + "C > " + String(thTemp, 1) + "C");
  }
  if (heatStrainPred && activeAlertCount == 0) {
    addAlert(5, false, "HEAT-UV STRAIN", "Compound UV+Thermal risk");
  } else if (uvIndex >= warnUv && uvIndex < urgUv) {
    addAlert(5, false, "UV ADVISORY", "UV " + String(uvIndex) + ": Wear SPF 30+");
  }
  if (!spfLogged && uvIndex >= 3) {
    addAlert(6, false, "LOG SPF", "SPF not logged yet");
  } else if (spfLogged && sunElapsedMin >= sLim) {
    addAlert(6, false, "REAPPLY SPF", String(sunElapsedMin) + "m elapsed");
  }
  if (batValid && batPct <= 15) {
    addAlert(7, false, "LOW BATTERY", "LiPo at " + String(batPct) + "% (" + String(batVolts, 2) + "V)");
  }
  if (!scoreValid && !simOverride && millis() > 10000UL) {
    addAlert(8, false, "SENSOR SIGNAL", hasTemp() ? "Check MAX contact" : "Check DS18B20");
  }

  alertActive = (activeAlertCount > 0);

  // Trigger Edge Takeover when any NEW alert bit turns ON
  uint16_t newlyFired = mask & (~prevRuleMask);
  if (newlyFired != 0) {
    alertLatched = true;
    watchScreen = 6; // Jump OLED straight to Edge Alert screen
    lastAlarmCycleMs = 0; // Fire immediate haptic + buzzer alert
  }
  if (!alertActive) {
    alertLatched = false;
  }
  prevRuleMask = mask;
}

// ======================================================================================
//  TTP223R CAPACITIVE TOUCH (GPIO 4) + BOOT BUTTON (GPIO 9) GESTURE ENGINE
//  - Single Tap  : Dismiss Active Alert OR Cycle OLED Watch Screen (0..6)
//  - Double Tap  : Toggle Personalized Skin Sensitivity Mode (Normal <-> Sensitive)
//  - Long Hold   : Log Sunscreen Reapplication (resets SPF timer)
// ======================================================================================
void pollTouchGestures() {
  unsigned long now = millis();

  bool ttpActive  = invTouch ? (digitalRead(PIN_TOUCH) == LOW) : (digitalRead(PIN_TOUCH) == HIGH);
  bool bootActive = (digitalRead(PIN_BOOT_BTN) == LOW);
  bool rawActive  = ttpActive || bootActive;
  touchNow = rawActive;

  if (rawActive != touchRawPrev) {
    touchDebounceMs = now;
    touchRawPrev = rawActive;
  }

  if ((now - touchDebounceMs) > 28) {
    // Rising edge: Finger touched TTP223R pad
    if (rawActive && !touchStable) {
      touchStable = true;
      touchDownMs = now;
      touchLongHandled = false;
      triggerHapticPulses(1, 35); // Crisp tactile touch response!
    }

    // Held >= 1000ms: Long-Hold Gesture -> Log Sunscreen SPF!
    if (touchStable && rawActive && !touchLongHandled && (now - touchDownMs >= 1000)) {
      touchLongHandled = true;
      tapPendingCount = 0;
      sunElapsedMin = 0;
      spfLogged = true;
      lastMinuteMs = now;
      sunSeq++;
      lastTouchGesture = "hold_spf";
      triggerHapticPulses(3, 55);
      triggerAudioPip(90, 2600);
    }

    // Falling edge: Finger lifted
    if (!rawActive && touchStable) {
      touchStable = false;
      if (!touchLongHandled) {
        // If an Edge Safety Alert is ringing, immediate single-tap dismisses it!
        if (alertLatched && alertActive) {
          alertLatched = false;
          ackSeq++;
          lastTouchGesture = "ack_alert";
          setBuzzerRaw(false);
          triggerHapticPulses(1, 60);
          tapPendingCount = 0;
        } else {
          tapPendingCount++;
          lastTapReleaseMs = now;
        }
      }
    }
  }

  // Resolve Single Tap vs Double Tap window (280 ms)
  if (tapPendingCount > 0 && !touchStable) {
    if (tapPendingCount >= 2) {
      tapPendingCount = 0;
      sensitiveSkin = !sensitiveSkin;
      sensSeq++;
      lastTouchGesture = sensitiveSkin ? "double_sens_on" : "double_sens_off";
      triggerHapticPulses(2, 50);
      triggerAudioPip(70, sensitiveSkin ? 2500 : 1750);
      evaluateEdgeSafety();
    } else if (now - lastTapReleaseMs >= 280) {
      tapPendingCount = 0;
      watchScreen = (watchScreen + 1) % NUM_SCREENS;
      scrSeq++;
      lastTouchGesture = "tap_next";
      triggerAudioPip(22, 2000);
    }
  }
}

// ======================================================================================
//  0.96" YELLOW + BLUE SSD1306 OLED RENDERER (128x64)
//  - Strict Zone Split:
//      y = 0..15  (Top 16px = Physical YELLOW OLED Phosphor -> Status & Battery Bar)
//      y = 16..63 (Bottom 48px = Physical BLUE OLED Phosphor -> Main Watch Cards)
// ======================================================================================
void drawBatteryGlyph(int x, int y, int pct) {
  display.drawRect(x, y, 18, 9, SSD1306_WHITE);
  display.fillRect(x + 18, y + 2, 2, 5, SSD1306_WHITE);
  int fillW = constrain((int)roundf((pct / 100.0f) * 14.0f), 0, 14);
  if (fillW > 0) display.fillRect(x + 2, y + 2, fillW, 5, SSD1306_WHITE);
}

void drawYellowTopBar() {
  display.setTextSize(1);
  display.setCursor(0, 3);
  if (alertActive) {
    display.print("!AURA");
  } else {
    display.print("AURA");
  }

  // Mode badge in center of Yellow Zone
  display.setCursor(32, 3);
  if (simOverride) display.print("[TEST]"); // Never disguise simulated readings as live on the wrist.
  else if (sensitiveSkin) display.print("[SENS]");
  else if (standaloneSim) display.print("[EDGE]");
  else if (!buzEnabled) display.print("[MUTE]");
  else display.print(scoreValid ? ("S:" + String(auraScore)) : "S:--");

  // Battery Percentage + Icon on right of Yellow Zone
  String bp = batValid ? (String(batPct) + "%") : "--%";
  int txtX = 106 - (bp.length() * 6);
  display.setCursor(txtX, 3);
  display.print(bp);
  drawBatteryGlyph(108, 2, batValid ? batPct : 0);
}

void renderOledWatch() {
  if (!oledOk) return;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  // 1. Render Top 16px YELLOW Zone (y = 0..15)
  drawYellowTopBar();

  // 2. Render Bottom 48px BLUE Zone (y = 17..63 — never crosses y=15/16 boundary!)
  switch (watchScreen) {
    case 0: { // Screen 0: Home + Composite Safety Score
      display.setTextSize(2);
      display.setCursor(0, 19);
      if (scoreValid) display.print(auraScore); else display.print("--");
      display.setTextSize(1);
      display.print("/100 ");
      display.print(auraBand);

      display.setCursor(0, 39);
      display.print("HR:");
      if (hasHr()) display.print(hrBpm); else display.print("--");
      display.print(" SpO2:");
      if (hasSpo2()) display.print(spo2Pct); else display.print("--");
      display.print("%");

      display.setCursor(0, 52);
      display.print("UV:");
      display.print(uvIndex);
      display.print("  T:");
      if (hasTemp()) display.print(tempC, 1); else display.print("--");
      display.print("C");
      break;
    }

    case 1: { // Screen 1: Heart Rate (MAX30102)
      display.setTextSize(1);
      display.setCursor(0, 18);
      display.print("HEART RATE (MAX30102)");
      display.setTextSize(2);
      display.setCursor(0, 31);
      if (hasHr()) display.print(hrBpm); else display.print("--");
      display.setTextSize(1);
      display.print(" BPM");

      display.setCursor(0, 53);
      if (!hasHr()) {
        display.print(maxOk ? "Waiting for contact" : "MAX30102 not found");
      } else if (hrBpm > thHrHigh || hrBpm < thHrLow) {
        display.print("! Limit ");
        display.print(thHrLow); display.print("-"); display.print(thHrHigh);
      } else {
        display.print("Pulse OK (");
        display.print(thHrLow); display.print("-"); display.print(thHrHigh); display.print(")");
      }
      break;
    }

    case 2: { // Screen 2: Blood Oxygen SpO2 (MAX30102)
      display.setTextSize(1);
      display.setCursor(0, 18);
      display.print("BLOOD OXYGEN (SpO2)");
      display.setTextSize(2);
      display.setCursor(0, 31);
      if (hasSpo2()) display.print(spo2Pct); else display.print("--");
      display.print("%");

      display.setCursor(0, 53);
      if (!hasSpo2()) {
        display.print(maxOk ? "Waiting for contact" : "MAX30102 not found");
      } else if (spo2Pct < thSpo2) {
        display.print("! HYPOXIA < ");
        display.print(thSpo2); display.print("%");
      } else {
        display.print("Saturation Nominal");
      }
      break;
    }

    case 3: { // Screen 3: Temperature (DS18B20)
      display.setTextSize(1);
      display.setCursor(0, 18);
      display.print("THERMAL (DS18B20)");
      display.setTextSize(2);
      display.setCursor(0, 31);
      if (hasTemp()) display.print(tempC, 1); else display.print("--");
      display.setTextSize(1);
      display.print(" C");

      display.setCursor(0, 53);
      if (!hasTemp()) {
        display.print("Sensor unavailable");
      } else if (tempC > thTemp) {
        display.print("! HEAT ALERT > ");
        display.print(thTemp, 1); display.print("C");
      } else {
        display.print(dsSensorFound ? "Raw:" : "Sim:");
        display.print(rawTempC, 1);
        display.print("C Max:");
        display.print(thTemp, 1);
      }
      break;
    }

    case 4: { // Screen 4: Real-Time UV + Personalized Skin Mode + SPF
      display.setTextSize(1);
      display.setCursor(0, 18);
      display.print("UV EXPOSURE ");
      display.print(sensitiveSkin ? "(SENS)" : "(NORM)");

      display.setTextSize(2);
      display.setCursor(0, 30);
      display.print("UV ");
      display.print(uvIndexFloat, 1);

      int sLim = sunLimitMinutes();
      int rem = max(0, sLim - sunElapsedMin);
      display.setTextSize(1);
      display.setCursor(0, 52);
      display.print("SPF:");
      if (!spfLogged) display.print("HOLD TO LOG");
      else if (rem == 0) display.print("REAPPLY NOW!");
      else { display.print(rem); display.print("m left (Hold=Log)"); }
      break;
    }

    case 5: { // Screen 5: Battery Percentage & Hardware Diagnostics
      display.setTextSize(1);
      display.setCursor(0, 18);
      display.print("TP4056 BATTERY / LINK");

      display.setTextSize(2);
      display.setCursor(0, 30);
      if (batValid) display.print(batPct); else display.print("--");
      display.print("% ");
      display.setTextSize(1);
      if (batValid) { display.print(batVolts, 2); display.print("V"); }
      else display.print("NO DIVIDER");

      display.setCursor(0, 52);
      display.print("WiFi:");
      display.print(WiFi.softAPIP());
      break;
    }

    default: { // Screen 6: Instant On-Wrist Edge Safety Alert Screen
      if (alertActive) {
        display.setTextSize(1);
        display.setCursor(0, 18);
        display.print(alertUrgent ? "!! URGENT EDGE ALERT" : "! SAFETY ADVISORY");

        display.setCursor(0, 31);
        display.print(topAlertTitle);
        if (activeAlertCount > 1) {
          display.print(" (+");
          display.print(activeAlertCount - 1);
          display.print(")");
        }

        display.setCursor(0, 42);
        display.print(topAlertDetail.substring(0, 21));

        display.setCursor(0, 54);
        display.print(alertLatched ? ">> Tap Touch to ACK" : "Acked - Monitoring");
      } else {
        display.setTextSize(2);
        display.setCursor(10, 24);
        display.print(scoreValid ? "ALL CLEAR" : "NO DATA");
        display.setTextSize(1);
        display.setCursor(6, 48);
        display.print(scoreValid ? "Edge Safety Active" : "Check vital sensors");
      }
      break;
    }
  }

  display.display();
}

// ======================================================================================
//  TWO-WAY TELEMETRY JSON & COMMAND PARSER (Wi-Fi HTTP + USB Web Serial)
// ======================================================================================
String buildTelemetryJson() {
  String j = "{";
  j += "\"fw\":\"project-aura-c3-2.1\",";
  j += "\"mcu\":\"ESP32-C3-SuperMini\",";
  j += "\"hr\":" + (hasHr() ? String(hrBpm) : String("null")) + ",";
  j += "\"spo2\":" + (hasSpo2() ? String(spo2Pct) : String("null")) + ",";
  j += "\"temp\":" + (hasTemp() ? String(tempC, 1) : String("null")) + ",";
  j += "\"tempRaw\":" + (tempValid ? String(rawTempC, 1) : String("null")) + ",";
  j += "\"uv\":" + String(uvIndex) + ",";
  j += "\"uvFloat\":" + String(uvIndexFloat, 1) + ",";
  j += "\"uvMv\":" + String(uvMilliVolts) + ",";
  j += "\"bat\":" + (batValid ? String(batPct) : String("null")) + ",";
  j += "\"batV\":" + (batValid ? String(batVolts, 2) : String("null")) + ",";
  j += "\"batHw\":" + String(batHwDetected ? "true" : "false") + ",";
  j += "\"batSense\":" + String(batterySenseEnabled ? "true" : "false") + ",";
  j += "\"batSenseSaveOk\":" + String(batterySenseSaveOk ? "true" : "false") + ",";
  j += "\"score\":" + (scoreValid ? String(auraScore) : String("null")) + ",";
  j += "\"band\":\"" + String(auraBand) + "\",";
  j += "\"heatPred\":" + String(heatStrainPred ? "true" : "false") + ",";
  j += "\"hrValid\":" + String(hasHr() ? "true" : "false") + ",";
  j += "\"spo2Valid\":" + String(hasSpo2() ? "true" : "false") + ",";
  j += "\"tempValid\":" + String(hasTemp() ? "true" : "false") + ",";
  j += "\"tempOffsetOn\":" + String(useBodyOffset ? "true" : "false") + ",";
  j += "\"uvGain\":" + String(uvGain, 2) + ",";
  j += "\"maxOk\":" + String(maxOk ? "true" : "false") + ",";
  j += "\"finger\":" + String(fingerDetected ? "true" : "false") + ",";
  j += "\"dsOk\":" + String((dsSensorFound && tempValid) ? "true" : "false") + ",";
  j += "\"oledOk\":" + String(oledOk ? "true" : "false") + ",";
  j += "\"touch\":" + String(touchNow ? "true" : "false") + ",";
  j += "\"gesture\":\"" + lastTouchGesture + "\",";
  j += "\"sens\":" + String(sensitiveSkin ? "true" : "false") + ",";
  j += "\"sensSeq\":" + String(sensSeq) + ",";
  j += "\"standalone\":" + String(standaloneSim ? "true" : "false") + ",";
  j += "\"th\":{\"hl\":" + String(thHrLow) + ",\"hh\":" + String(thHrHigh) + ",\"sp\":" + String(thSpo2) + ",\"tp\":" + String(thTemp, 1) + "},";
  j += "\"sun\":" + String(sunElapsedMin) + ",";
  j += "\"spfLogged\":" + String(spfLogged ? "true" : "false") + ",";
  j += "\"exposureMin\":" + String(exposureMinutes, 2) + ",";
  j += "\"uvDose\":" + String(uvIndexMinutes, 2) + ",";
  j += "\"sunSeq\":" + String(sunSeq) + ",";
  j += "\"snd\":" + String(buzEnabled ? "true" : "false") + ",";
  j += "\"vib\":" + String(vibEnabled ? "true" : "false") + ",";
  j += "\"buzMode\":" + String(buzMode) + ",";
  j += "\"invBuz\":" + String(invBuz ? "true" : "false") + ",";
  j += "\"invTouch\":" + String(invTouch ? "true" : "false") + ",";
  j += "\"buzOn\":" + String(buzCurrentlyOn ? "true" : "false") + ",";
  j += "\"vibOn\":" + String(vibCurrentlyOn ? "true" : "false") + ",";
  j += "\"simOverride\":" + String(simOverride ? "true" : "false") + ",";
  j += "\"scr\":" + String(watchScreen) + ",";
  j += "\"scrSeq\":" + String(scrSeq) + ",";
  j += "\"ackSeq\":" + String(ackSeq) + ",";
  j += "\"alertActive\":" + String(alertActive ? "true" : "false") + ",";
  j += "\"alertLatched\":" + String(alertLatched ? "true" : "false") + ",";
  j += "\"raw\":{\"ir\":" + String(latestIr) + ",\"red\":" + String(latestRed) + ",\"uvMv\":" + String(uvMilliVolts) + "}";
  j += "}";
  return j;
}

void applyKeyValue(const String& key, const String& val) {
  if (key == "scr") watchScreen = constrain(val.toInt(), 0, NUM_SCREENS - 1);
  else if (key == "ack" && val == "1") { alertLatched = false; setBuzzerRaw(false); }
  else if (key == "sens") sensitiveSkin = (val == "1" || val == "true");
  else if (key == "snd") {
    buzEnabled = (val == "1" || val == "true");
    if (!buzEnabled) setBuzzerRaw(false);
  }
  else if (key == "vib") {
    vibEnabled = (val == "1" || val == "true");
    if (!vibEnabled) setVibMotorRaw(false);
  }
  else if (key == "buzMode") { buzMode = constrain(val.toInt(), 0, 1); setBuzzerRaw(false); }
  else if (key == "invBuz")  { invBuz = (val == "1" || val == "true"); setBuzzerRaw(false); }
  else if (key == "invTouch") invTouch = (val == "1" || val == "true");
  else if (key == "testBuz" && val == "1") {
    bool prev = buzEnabled; buzEnabled = true;
    triggerAudioPip(180, 2450);
    buzEnabled = prev;
  }
  else if (key == "testVib" && val == "1") {
    bool prev = vibEnabled; vibEnabled = true;
    triggerHapticPulses(2, 90);
    vibEnabled = prev;
  }
  else if (key == "sunReset" && val == "1") { sunElapsedMin = 0; spfLogged = true; lastMinuteMs = millis(); }
  else if (key == "sun") { sunElapsedMin = constrain(val.toInt(), 0, 240); spfLogged = true; lastMinuteMs = millis(); }
  else if (key == "expReset" && val == "1") { exposureMinutes = 0; uvIndexMinutes = 0; }
  else if (key == "batSense") {
    bool requested = (val == "1" || val == "true");
    // Never write flash on every poll: save only when changed or a failed save is retried.
    if (requested != batterySenseEnabled || !batterySenseSaveOk) {
      batterySenseEnabled = requested;
      batterySenseSaveOk = saveBatterySenseSetting(requested);
    }
    batVoltageEma = 0;
  }
  else if (key == "bat") simBat = constrain(val.toInt(), 0, 100); // ONLY visible when simOverride is on
  else if (key == "uvGain") uvGain = constrain(val.toFloat(), 0.5f, 8.0f);
  else if (key == "useOffset") useBodyOffset = (val == "1" || val == "true");
  else if (key == "rezero" && val == "1") { tempOffset = 36.8f - rawTempC; useBodyOffset = true; }
  else if (key == "standalone") standaloneSim = (val == "1" || val == "true");
  else if (key == "simOverride") {
    bool next = (val == "1" || val == "true");
    if (simOverride && !next) {
      hrValid = spo2Valid = tempValid = batValid = false;
      spfLogged = false; sunElapsedMin = 0; lastMinuteMs = millis(); // Demo timer is not real SPF history.
    }
    simOverride = next;
  }
  else if (key == "simHr")   simHr = constrain(val.toInt(), 35, 200);
  else if (key == "simSpo2") simSpo2 = constrain(val.toInt(), 80, 100);
  else if (key == "simTemp") simTemp = constrain(val.toFloat(), 20.0f, 43.0f);
  else if (key == "simUv")   simUv = constrain(val.toInt(), -1, 12);
  else if (key == "hl") thHrLow  = constrain(val.toInt(), 35, 95);
  else if (key == "hh") thHrHigh = constrain(val.toInt(), 90, 210);
  else if (key == "sp") thSpo2   = constrain(val.toInt(), 80, 99);
  else if (key == "tp") thTemp   = constrain(val.toFloat(), 20.0f, 43.0f);
}

void parseQueryCommandString(String qs) {
  qs.trim();
  int start = 0;
  while (start < (int)qs.length()) {
    int amp = qs.indexOf('&', start);
    if (amp < 0) amp = qs.length();
    String pair = qs.substring(start, amp);
    int eq = pair.indexOf('=');
    if (eq > 0) {
      applyKeyValue(pair.substring(0, eq), pair.substring(eq + 1));
    }
    start = amp + 1;
  }
  evaluateEdgeSafety();
}

void pollUsbSerialCommands() {
  static String line;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n') {
      line.trim();
      if (line.startsWith("CMD:")) parseQueryCommandString(line.substring(4));
      line = "";
    } else if (c != '\r') {
      if (line.length() < 400) line += c;
      else line = "";
    }
  }
}

void addCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
}

void setupHttpServer() {
  server.on("/", HTTP_GET, []() {
    addCorsHeaders();
    String html = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                  "<title>Project AURA ESP32-C3 Node</title>"
                  "<style>body{font-family:system-ui;background:#07101f;color:#eef6ff;padding:20px}"
                  "pre{background:#101e36;padding:14px;border-radius:12px;border:1px solid #26406b;overflow:auto}</style></head><body>"
                  "<h2 style='color:#ffd43b;margin:0'>Project AURA — ESP32-C3 SuperMini Edge Node</h2>"
                  "<p style='color:#38e2ff'>Advanced UV &amp; Risk-prediction Assistant · Live Telemetry Active</p>"
                  "<pre id='out'>Loading...</pre>"
                  "<script>setInterval(()=>fetch('/status').then(r=>r.json()).then(d=>out.textContent=JSON.stringify(d,null,2)),350);</script>"
                  "</body></html>";
    server.send(200, "text/html", html);
  });

  server.on("/status", HTTP_OPTIONS, []() { addCorsHeaders(); server.send(204); });
  server.on("/status", HTTP_GET, []() {
    addCorsHeaders();
    server.send(200, "application/json", buildTelemetryJson());
  });

  server.on("/cmd", HTTP_OPTIONS, []() { addCorsHeaders(); server.send(204); });
  server.on("/cmd", HTTP_GET, []() {
    for (int i = 0; i < server.args(); i++) {
      applyKeyValue(server.argName(i), server.arg(i));
    }
    evaluateEdgeSafety();
    addCorsHeaders();
    server.send(200, "application/json", buildTelemetryJson());
  });

  server.begin();
}

// ======================================================================================
//  SETUP & MAIN LOOP
// ======================================================================================
void setup() {
  Serial.begin(115200);
  restoreBatterySenseSetting(); // Load the user's prior confirmation before the first ADC reading.

  // Configure GPIO inputs & actuators
  pinMode(PIN_TOUCH, INPUT);           // TTP223R actively drives HIGH/LOW
  pinMode(PIN_BOOT_BTN, INPUT_PULLUP); // ESP32-C3 onboard BOOT button backup
  pinMode(PIN_VIB_MOTOR, OUTPUT);
  digitalWrite(PIN_VIB_MOTOR, LOW);
  pinMode(PIN_BUZZER, OUTPUT);
  setBuzzerRaw(false);
  pinMode(PIN_STATUS_LED, OUTPUT);
  digitalWrite(PIN_STATUS_LED, HIGH);  // Active-LOW Blue LED OFF

  // Configure ESP32-C3 Calibrated ADC1 Channels (0 - 2500 mV @ 11dB)
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_UV_ADC, ADC_11db);
  analogSetPinAttenuation(PIN_BAT_ADC, ADC_11db);

  // Initialize Shared I2C Bus on Safe ESP32-C3 Pins (SDA = GPIO 6, SCL = GPIO 7)
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.setClock(400000);

  // 1. Probe the OLED: display.begin() alone allocates memory, not an I2C presence test.
  Wire.beginTransmission(0x3C);
  bool oledPresent = (Wire.endTransmission() == 0);
  if (!oledPresent) {
    Wire.beginTransmission(0x3D);
    if (Wire.endTransmission() == 0) { oledAddr = 0x3D; oledPresent = true; }
  }
  oledOk = oledPresent && display.begin(SSD1306_SWITCHCAPVCC, oledAddr, true, false); // Keep custom Wire pins.
  if (oledOk) {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(10, 3);
    display.print("PROJECT AURA v2.1"); // Yellow top band!
    display.setCursor(4, 22);
    display.print("Adv. UV & Risk-Pred.");
    display.setCursor(4, 36);
    display.print("ESP32-C3 SuperMini");
    display.setCursor(4, 50);
    display.print("Booting sensors...");
    display.display();
  }

  // 2. Initialize MAX30102 Heart Rate & Pulse Oximeter on same I2C bus (0x57)
  if (particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    maxOk = true;
    byte ledBrightness = 0x24; // Balanced Red/IR current for finger/wrist PPG
    byte sampleAverage = 4;
    byte ledMode       = 2;    // Red + IR (HR + SpO2)
    int  sampleRate    = 400;
    int  pulseWidth    = 411;
    int  adcRange      = 4096;
    particleSensor.setup(ledBrightness, sampleAverage, ledMode, sampleRate, pulseWidth, adcRange);
  }

  // 3. Initialize DS18B20 Temperature Sensor on GPIO 3 (+ 10k pull-up to 3V3)
  ds18b20.begin();
  dsSensorFound = (ds18b20.getDeviceCount() > 0);
  if (dsSensorFound) {
    ds18b20.setResolution(10);
    ds18b20.setWaitForConversion(false);
    ds18b20.requestTemperatures();
    delay(200);
    float initT = ds18b20.getTempCByIndex(0);
    if (initT > -20.0f && initT < 70.0f) {
      rawTempC = initT;
      tempC = roundf(initT * 10.0f) / 10.0f;
      tempValid = true;
    }
    ds18b20.requestTemperatures();
  }
  lastMinuteMs = lastExposureMs = millis();

  // 4. Start Wi-Fi SoftAP + ESP32-C3 SuperMini RF Stability Fix (8.5 dBm TX power)
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  WiFi.setTxPower(WIFI_POWER_8_5dBm); // Prevents C3 SuperMini ceramic antenna brownout/drop!
  setupHttpServer();

  // Boot confirmation haptic tap + gentle chime
  triggerHapticPulses(1, 65);
  triggerAudioPip(80, 2300);
}

void loop() {
  server.handleClient();
  pollUsbSerialCommands();
  pollTouchGestures();
  pollMax30102();
  pollAnalogAndTemp();
  evaluateEdgeSafety();
  serviceActuators();

  unsigned long now = millis();
  if (now - lastOledMs >= 160) {
    lastOledMs = now;
    renderOledWatch();
  }
  if (now - lastSerialMs >= 200) {
    lastSerialMs = now;
    Serial.println(buildTelemetryJson());
  }
}
