#!/usr/bin/env python3
"""Optional Project AURA local browser bridge. Standard library only.

Run on the computer connected to the Project-AURA hotspot:
    python3 aura_bridge.py
Then visit http://localhost:8765/?bridge=1 (or /studio?bridge=1).
This is a local proxy, not a cloud service or a phone push server.
"""
from __future__ import annotations
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
import json
import socket

ROOT = Path(__file__).resolve().parent
PAGES = {
    "/": "Project AURA – Advanced UV & Risk-prediction Assistant.html",
    "/studio": "project_aura_dashboard.html",
}

class Handler(BaseHTTPRequestHandler):
    server_version = "AURALocalBridge/1.0"

    def reply(self, code: int, content: bytes, ctype: str = "text/plain; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        # Local-only binding and Host validation mitigate accidental exposure/DNS rebinding.
        host = self.headers.get("Host", "").lower()
        if host not in {f"localhost:{self.server.server_port}", f"127.0.0.1:{self.server.server_port}"}:
            self.reply(403, b"Open using localhost or 127.0.0.1 on the local computer.")
            return
        path = urlsplit(self.path)
        if path.path in PAGES:
            filename = ROOT / PAGES[path.path]
            try:
                self.reply(200, filename.read_bytes(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self.reply(404, f"Missing {filename.name}; keep it beside aura_bridge.py.".encode())
            return
        if path.path not in ("/aura/status", "/aura/cmd"):
            self.reply(404, b"Not found")
            return
        # A cross-site page cannot set this header without a successful CORS preflight;
        # this server deliberately does not provide CORS or OPTIONS access.
        if self.headers.get("X-AURA-Bridge") != "1" or self.headers.get("Sec-Fetch-Site") == "cross-site":
            self.reply(403, b"Local Project AURA page header required")
            return
        suffix = "/status" if path.path.endswith("status") else "/cmd"
        remote = self.server.device.rstrip("/") + suffix + (("?" + path.query) if path.query else "")
        try:
            request = Request(remote, headers={"Accept": "application/json", "Cache-Control": "no-cache"})
            with urlopen(request, timeout=2.5) as response:
                content = response.read(65536)
                self.reply(response.status, content, "application/json; charset=utf-8")
        except (URLError, TimeoutError, socket.timeout, OSError) as exc:
            body = json.dumps({"error": "ESP32 unreachable", "detail": str(exc)}).encode()
            self.reply(502, body, "application/json; charset=utf-8")

    def log_message(self, fmt, *args):
        # 200 ms status polls are intentionally quiet; keep errors visible.
        if not (self.path.startswith("/aura/status") and str(args[1]) == "200"):
            super().log_message(fmt, *args)


def main():
    ap = argparse.ArgumentParser(description="Local browser-to-ESP32 Wi-Fi bridge for Project AURA")
    ap.add_argument("--port", type=int, default=8765, help="local loopback port (default 8765)")
    ap.add_argument("--device", default="http://192.168.4.1", help="ESP32 HTTP origin")
    args = ap.parse_args()
    dev = urlsplit(args.device)
    if dev.scheme not in ("http", "https") or not dev.hostname or dev.username or dev.password or dev.query or dev.fragment or dev.path not in ("", "/"):
        ap.error("--device must be an HTTP(S) origin, e.g. http://192.168.4.1")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.device = args.device
    print(f"Project AURA local bridge → {args.device}", flush=True)
    print(f"Companion: http://localhost:{args.port}/?bridge=1", flush=True)
    print(f"Studio:    http://localhost:{args.port}/studio?bridge=1", flush=True)
    print("Only accessible from this computer. Press Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBridge stopped.")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
